// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.TwistedOperators.IntegralRightTranslate
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.BlkGLMem public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.AdelicUnitaryTopology public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.AdelicUnitaryUnimodularExistsFundamentalDomain
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SquareComm_iterConv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SquareComm_iterConv___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SquareComm_iterConv(lean_object* v_D_1_, lean_object* v_M_2_, lean_object* v_X_3_, lean_object* v_V_4_, lean_object* v_00_u03c9_5_, lean_object* v_j_6_, lean_object* v_G_7_, lean_object* v_00_u03bd_8_, lean_object* v_00_U0001d4d5_9_, lean_object* v_00_u03bc_10_, lean_object* v_00_U0001d4d4_11_){
_start:
{
lean_object* v___x_12_; 
v___x_12_ = lean_box(0);
return v___x_12_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SquareComm_iterConv___boxed(lean_object* v_D_13_, lean_object* v_M_14_, lean_object* v_X_15_, lean_object* v_V_16_, lean_object* v_00_u03c9_17_, lean_object* v_j_18_, lean_object* v_G_19_, lean_object* v_00_u03bd_20_, lean_object* v_00_U0001d4d5_21_, lean_object* v_00_u03bc_22_, lean_object* v_00_U0001d4d4_23_){
_start:
{
lean_object* v_res_24_; 
v_res_24_ = lp_tree_GlobalTheory_SquareComm_iterConv(v_D_13_, v_M_14_, v_X_15_, v_V_16_, v_00_u03c9_17_, v_j_18_, v_G_19_, v_00_u03bd_20_, v_00_U0001d4d5_21_, v_00_u03bc_22_, v_00_U0001d4d4_23_);
lean_dec_ref(v_00_u03bc_22_);
lean_dec_ref(v_00_u03bd_20_);
lean_dec_ref(v_G_19_);
lean_dec_ref(v_j_18_);
lean_dec_ref(v_00_u03c9_17_);
lean_dec_ref(v_V_16_);
lean_dec_ref(v_X_15_);
lean_dec_ref(v_M_14_);
lean_dec_ref(v_D_13_);
return v_res_24_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_BlkGLMem(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_AdelicUnitaryTopology(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_AdelicUnitaryUnimodularExistsFundamentalDomain(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_IntegralRightTranslate(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_BlkGLMem(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_AdelicUnitaryTopology(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_AdelicUnitaryUnimodularExistsFundamentalDomain(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
