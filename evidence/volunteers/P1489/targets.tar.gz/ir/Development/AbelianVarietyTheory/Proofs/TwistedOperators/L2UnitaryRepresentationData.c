// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.TwistedOperators.L2UnitaryRepresentationData
// Imports: public import Init public meta import Init public import Mathlib public import Formalism.SharpRestriction.Divisibility.SchurIrreducible public import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.ThetaSourceAction public import Development.AbelianVarietyTheory.BlockTheory.TwistedDiscreteSeries.HalfLinearCocycle public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.ChosenSeries public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.HarishChandraModulesOn public import Development.AbelianVarietyTheory.PublishedTheorems.TwistedTraceFormula.AdmissibleDiscreteSeriesOfHasParam
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_BarMatrix_plainMat___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_BarMatrix_barMat___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
lean_object* lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_(lean_object*, lean_object*);
lean_object* lp_tree_GlobalTheory_Chain_signed(lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_Formalism_IndefR_Mult_dualPar(lean_object*);
lean_object* lp_mathlib_starRingEnd___at___00Complex_UnitDisc_conj_spec__0___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_phi___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_phi___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_phi(lean_object*, lean_object*, lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_phi___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_ArchRec_sg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_ArchRec_sg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_sg(uint8_t, uint8_t);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_sg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_parOf(uint8_t, uint8_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_parOf___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_cjc(uint8_t, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_cjc___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_phi___redArg(uint8_t v_br_1_, lean_object* v_e_2_, lean_object* v_Z_3_, lean_object* v_a_4_, lean_object* v_a_5_){
_start:
{
if (v_br_1_ == 0)
{
lean_object* v___x_6_; 
v___x_6_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_BarMatrix_plainMat___redArg(v_e_2_, v_Z_3_, v_a_4_, v_a_5_);
return v___x_6_;
}
else
{
lean_object* v___x_7_; 
v___x_7_ = lp_tree_GlobalTheory_IndefiniteRowSideFullHecke_BarMatrix_barMat___redArg(v_e_2_, v_Z_3_, v_a_4_, v_a_5_);
return v___x_7_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_phi___redArg___boxed(lean_object* v_br_8_, lean_object* v_e_9_, lean_object* v_Z_10_, lean_object* v_a_11_, lean_object* v_a_12_){
_start:
{
uint8_t v_br_boxed_13_; lean_object* v_res_14_; 
v_br_boxed_13_ = lean_unbox(v_br_8_);
v_res_14_ = lp_tree_GlobalTheory_ArchRec_phi___redArg(v_br_boxed_13_, v_e_9_, v_Z_10_, v_a_11_, v_a_12_);
return v_res_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_phi(lean_object* v_p_15_, lean_object* v_q_16_, lean_object* v_n_17_, uint8_t v_br_18_, lean_object* v_e_19_, lean_object* v_Z_20_, lean_object* v_a_21_, lean_object* v_a_22_){
_start:
{
lean_object* v___x_23_; 
v___x_23_ = lp_tree_GlobalTheory_ArchRec_phi___redArg(v_br_18_, v_e_19_, v_Z_20_, v_a_21_, v_a_22_);
return v___x_23_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_phi___boxed(lean_object* v_p_24_, lean_object* v_q_25_, lean_object* v_n_26_, lean_object* v_br_27_, lean_object* v_e_28_, lean_object* v_Z_29_, lean_object* v_a_30_, lean_object* v_a_31_){
_start:
{
uint8_t v_br_boxed_32_; lean_object* v_res_33_; 
v_br_boxed_32_ = lean_unbox(v_br_27_);
v_res_33_ = lp_tree_GlobalTheory_ArchRec_phi(v_p_24_, v_q_25_, v_n_26_, v_br_boxed_32_, v_e_28_, v_Z_29_, v_a_30_, v_a_31_);
lean_dec(v_n_26_);
lean_dec(v_q_25_);
lean_dec(v_p_24_);
return v_res_33_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_ArchRec_sg___closed__0(void){
_start:
{
lean_object* v___x_34_; lean_object* v___f_35_; 
v___x_34_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
v___f_35_ = lean_alloc_closure((void*)(lp_mathlib_Real_definition___lam__0_00___x40_Mathlib_Data_Real_Basic_2451848184____hygCtx___hyg_8_), 2, 1);
lean_closure_set(v___f_35_, 0, v___x_34_);
return v___f_35_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_sg(uint8_t v_br_36_, uint8_t v_cj_37_){
_start:
{
if (v_br_36_ == 0)
{
if (v_cj_37_ == 0)
{
lean_object* v___x_40_; 
v___x_40_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
return v___x_40_;
}
else
{
goto v___jp_38_;
}
}
else
{
if (v_cj_37_ == 0)
{
goto v___jp_38_;
}
else
{
lean_object* v___x_41_; 
v___x_41_ = lp_mathlib_Real_definition_00___x40_Mathlib_Data_Real_Basic_1279875089____hygCtx___hyg_8_;
return v___x_41_;
}
}
v___jp_38_:
{
lean_object* v___f_39_; 
v___f_39_ = lean_obj_once(&lp_tree_GlobalTheory_ArchRec_sg___closed__0, &lp_tree_GlobalTheory_ArchRec_sg___closed__0_once, _init_lp_tree_GlobalTheory_ArchRec_sg___closed__0);
return v___f_39_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_sg___boxed(lean_object* v_br_42_, lean_object* v_cj_43_){
_start:
{
uint8_t v_br_boxed_44_; uint8_t v_cj_boxed_45_; lean_object* v_res_46_; 
v_br_boxed_44_ = lean_unbox(v_br_42_);
v_cj_boxed_45_ = lean_unbox(v_cj_43_);
v_res_46_ = lp_tree_GlobalTheory_ArchRec_sg(v_br_boxed_44_, v_cj_boxed_45_);
return v_res_46_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_parOf(uint8_t v_br_47_, uint8_t v_cj_48_, lean_object* v_l_u2081_49_, lean_object* v_l_u2082_50_, lean_object* v_c_51_){
_start:
{
if (v_br_47_ == 0)
{
if (v_cj_48_ == 0)
{
lean_object* v___x_55_; 
v___x_55_ = lp_tree_GlobalTheory_Chain_signed(v_l_u2081_49_, v_l_u2082_50_, v_c_51_);
return v___x_55_;
}
else
{
goto v___jp_52_;
}
}
else
{
if (v_cj_48_ == 0)
{
goto v___jp_52_;
}
else
{
lean_object* v___x_56_; 
v___x_56_ = lp_tree_GlobalTheory_Chain_signed(v_l_u2081_49_, v_l_u2082_50_, v_c_51_);
return v___x_56_;
}
}
v___jp_52_:
{
lean_object* v___x_53_; lean_object* v___x_54_; 
v___x_53_ = lp_tree_GlobalTheory_Chain_signed(v_l_u2081_49_, v_l_u2082_50_, v_c_51_);
v___x_54_ = lp_tree_Formalism_IndefR_Mult_dualPar(v___x_53_);
return v___x_54_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_parOf___boxed(lean_object* v_br_57_, lean_object* v_cj_58_, lean_object* v_l_u2081_59_, lean_object* v_l_u2082_60_, lean_object* v_c_61_){
_start:
{
uint8_t v_br_boxed_62_; uint8_t v_cj_boxed_63_; lean_object* v_res_64_; 
v_br_boxed_62_ = lean_unbox(v_br_57_);
v_cj_boxed_63_ = lean_unbox(v_cj_58_);
v_res_64_ = lp_tree_GlobalTheory_ArchRec_parOf(v_br_boxed_62_, v_cj_boxed_63_, v_l_u2081_59_, v_l_u2082_60_, v_c_61_);
return v_res_64_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_cjc(uint8_t v_cj_65_, lean_object* v_z_66_){
_start:
{
if (v_cj_65_ == 0)
{
return v_z_66_;
}
else
{
lean_object* v___x_67_; 
v___x_67_ = lp_mathlib_starRingEnd___at___00Complex_UnitDisc_conj_spec__0___lam__0(v_z_66_);
return v___x_67_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_ArchRec_cjc___boxed(lean_object* v_cj_68_, lean_object* v_z_69_){
_start:
{
uint8_t v_cj_boxed_70_; lean_object* v_res_71_; 
v_cj_boxed_70_ = lean_unbox(v_cj_68_);
v_res_71_ = lp_tree_GlobalTheory_ArchRec_cjc(v_cj_boxed_70_, v_z_69_);
return v_res_71_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_Divisibility_SchurIrreducible(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_ThetaSourceAction(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_HalfLinearCocycle(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ChosenSeries(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HarishChandraModulesOn(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_AdmissibleDiscreteSeriesOfHasParam(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_L2UnitaryRepresentationData(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_Divisibility_SchurIrreducible(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_ThetaSourceAction(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_BlockTheory_TwistedDiscreteSeries_HalfLinearCocycle(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ChosenSeries(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_HarishChandraModulesOn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_PublishedTheorems_TwistedTraceFormula_AdmissibleDiscreteSeriesOfHasParam(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
