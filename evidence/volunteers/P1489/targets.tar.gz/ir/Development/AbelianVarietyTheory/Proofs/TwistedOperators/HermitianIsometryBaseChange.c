// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.TwistedOperators.HermitianIsometryBaseChange
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.TwistedInnerProducts.ExistsHasCls
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_NonUnitalRingHom_id___lam__0___boxed(lean_object*);
lean_object* lp_mathlib_Algebra_TensorProduct_map___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_closure_object lp_tree_GlobalTheory_TrEll_BaseChg_mapE___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_mathlib_NonUnitalRingHom_id___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_tree_GlobalTheory_TrEll_BaseChg_mapE___redArg___closed__0 = (const lean_object*)&lp_tree_GlobalTheory_TrEll_BaseChg_mapE___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TrEll_BaseChg_mapE___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TrEll_BaseChg_mapE___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TrEll_BaseChg_mapE(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TrEll_BaseChg_mapE___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TrEll_BaseChg_mapE___redArg(lean_object* v_inst_2_, lean_object* v_inst_3_, lean_object* v_inst_4_, lean_object* v_inst_5_, lean_object* v_inst_6_, lean_object* v_00_u03c8_7_){
_start:
{
lean_object* v___x_8_; lean_object* v_toCommSemiring_9_; lean_object* v___x_10_; lean_object* v___x_11_; lean_object* v_toSemiring_12_; lean_object* v_toSemiring_13_; lean_object* v___f_14_; lean_object* v___x_15_; 
v___x_8_ = lp_mathlib_Field_toSemifield___redArg(v_inst_2_);
v_toCommSemiring_9_ = lean_ctor_get(v___x_8_, 0);
lean_inc_ref(v_toCommSemiring_9_);
lean_dec_ref(v___x_8_);
v___x_10_ = lp_mathlib_Field_toSemifield___redArg(v_inst_3_);
v___x_11_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_10_);
v_toSemiring_12_ = lean_ctor_get(v___x_11_, 0);
lean_inc_ref_n(v_toSemiring_12_, 2);
lean_dec_ref(v___x_11_);
v_toSemiring_13_ = lean_ctor_get(v_inst_5_, 0);
lean_inc_ref(v_toSemiring_13_);
lean_dec_ref(v_inst_5_);
v___f_14_ = ((lean_object*)(lp_tree_GlobalTheory_TrEll_BaseChg_mapE___redArg___closed__0));
lean_inc_ref(v_inst_4_);
v___x_15_ = lp_mathlib_Algebra_TensorProduct_map___redArg(v_toCommSemiring_9_, v_toSemiring_12_, v_inst_4_, v_toSemiring_13_, v_inst_6_, v_toSemiring_12_, v_inst_4_, v_00_u03c8_7_, v___f_14_);
return v___x_15_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TrEll_BaseChg_mapE___redArg___boxed(lean_object* v_inst_16_, lean_object* v_inst_17_, lean_object* v_inst_18_, lean_object* v_inst_19_, lean_object* v_inst_20_, lean_object* v_00_u03c8_21_){
_start:
{
lean_object* v_res_22_; 
v_res_22_ = lp_tree_GlobalTheory_TrEll_BaseChg_mapE___redArg(v_inst_16_, v_inst_17_, v_inst_18_, v_inst_19_, v_inst_20_, v_00_u03c8_21_);
lean_dec_ref(v_inst_17_);
lean_dec_ref(v_inst_16_);
return v_res_22_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TrEll_BaseChg_mapE(lean_object* v_F_23_, lean_object* v_E_24_, lean_object* v_inst_25_, lean_object* v_inst_26_, lean_object* v_inst_27_, lean_object* v_k_28_, lean_object* v_k_x27_29_, lean_object* v_inst_30_, lean_object* v_inst_31_, lean_object* v_inst_32_, lean_object* v_inst_33_, lean_object* v_00_u03c8_34_){
_start:
{
lean_object* v___x_35_; lean_object* v_toCommSemiring_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v_toSemiring_39_; lean_object* v_toSemiring_40_; lean_object* v___f_41_; lean_object* v___x_42_; 
v___x_35_ = lp_mathlib_Field_toSemifield___redArg(v_inst_25_);
v_toCommSemiring_36_ = lean_ctor_get(v___x_35_, 0);
lean_inc_ref(v_toCommSemiring_36_);
lean_dec_ref(v___x_35_);
v___x_37_ = lp_mathlib_Field_toSemifield___redArg(v_inst_26_);
v___x_38_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_37_);
v_toSemiring_39_ = lean_ctor_get(v___x_38_, 0);
lean_inc_ref_n(v_toSemiring_39_, 2);
lean_dec_ref(v___x_38_);
v_toSemiring_40_ = lean_ctor_get(v_inst_32_, 0);
lean_inc_ref(v_toSemiring_40_);
lean_dec_ref(v_inst_32_);
v___f_41_ = ((lean_object*)(lp_tree_GlobalTheory_TrEll_BaseChg_mapE___redArg___closed__0));
lean_inc_ref(v_inst_27_);
v___x_42_ = lp_mathlib_Algebra_TensorProduct_map___redArg(v_toCommSemiring_36_, v_toSemiring_39_, v_inst_27_, v_toSemiring_40_, v_inst_33_, v_toSemiring_39_, v_inst_27_, v_00_u03c8_34_, v___f_41_);
return v___x_42_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_TrEll_BaseChg_mapE___boxed(lean_object* v_F_43_, lean_object* v_E_44_, lean_object* v_inst_45_, lean_object* v_inst_46_, lean_object* v_inst_47_, lean_object* v_k_48_, lean_object* v_k_x27_49_, lean_object* v_inst_50_, lean_object* v_inst_51_, lean_object* v_inst_52_, lean_object* v_inst_53_, lean_object* v_00_u03c8_54_){
_start:
{
lean_object* v_res_55_; 
v_res_55_ = lp_tree_GlobalTheory_TrEll_BaseChg_mapE(v_F_43_, v_E_44_, v_inst_45_, v_inst_46_, v_inst_47_, v_k_48_, v_k_x27_49_, v_inst_50_, v_inst_51_, v_inst_52_, v_inst_53_, v_00_u03c8_54_);
lean_dec_ref(v_inst_51_);
lean_dec_ref(v_inst_50_);
lean_dec_ref(v_inst_46_);
lean_dec_ref(v_inst_45_);
return v_res_55_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_ExistsHasCls(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_HermitianIsometryBaseChange(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_TwistedInnerProducts_ExistsHasCls(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
