// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.TwistedOperators.FiniteLevelDatumClasses
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.RedMFrMapAdjZero
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Matrix_vecMulVec___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_LinearMap_mk_u2082_x27_u209b_u2097___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LiftLevel_vmvBil___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LiftLevel_vmvBil___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LiftLevel_vmvBil___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LiftLevel_vmvBil(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LiftLevel_vmvBil___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LiftLevel_vmvBil___redArg___lam__0(lean_object* v_toMul_1_, lean_object* v_v_2_, lean_object* v_u_3_, lean_object* v___y_4_, lean_object* v___y_5_){
_start:
{
lean_object* v___x_6_; 
v___x_6_ = lp_mathlib_Matrix_vecMulVec___redArg(v_toMul_1_, v_v_2_, v_u_3_, v___y_4_, v___y_5_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LiftLevel_vmvBil___redArg(lean_object* v_inst_7_){
_start:
{
lean_object* v___x_8_; lean_object* v___x_9_; lean_object* v_toSemiring_10_; lean_object* v___x_11_; lean_object* v_toMul_12_; lean_object* v___f_13_; lean_object* v___f_14_; 
v___x_8_ = lp_mathlib_Field_toSemifield___redArg(v_inst_7_);
v___x_9_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_8_);
v_toSemiring_10_ = lean_ctor_get(v___x_9_, 0);
lean_inc_ref(v_toSemiring_10_);
lean_dec_ref(v___x_9_);
v___x_11_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_10_);
v_toMul_12_ = lean_ctor_get(v___x_11_, 0);
lean_inc(v_toMul_12_);
lean_dec_ref(v___x_11_);
v___f_13_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_LiftLevel_vmvBil___redArg___lam__0), 5, 1);
lean_closure_set(v___f_13_, 0, v_toMul_12_);
v___f_14_ = lean_alloc_closure((void*)(lp_mathlib_LinearMap_mk_u2082_x27_u209b_u2097___redArg___lam__0), 3, 1);
lean_closure_set(v___f_14_, 0, v___f_13_);
return v___f_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LiftLevel_vmvBil___redArg___boxed(lean_object* v_inst_15_){
_start:
{
lean_object* v_res_16_; 
v_res_16_ = lp_tree_GlobalTheory_LiftLevel_vmvBil___redArg(v_inst_15_);
lean_dec_ref(v_inst_15_);
return v_res_16_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LiftLevel_vmvBil(lean_object* v_E_17_, lean_object* v_inst_18_, lean_object* v_inst_19_, lean_object* v_n_20_, lean_object* v_r_21_){
_start:
{
lean_object* v___x_22_; 
v___x_22_ = lp_tree_GlobalTheory_LiftLevel_vmvBil___redArg(v_inst_18_);
return v___x_22_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_LiftLevel_vmvBil___boxed(lean_object* v_E_23_, lean_object* v_inst_24_, lean_object* v_inst_25_, lean_object* v_n_26_, lean_object* v_r_27_){
_start:
{
lean_object* v_res_28_; 
v_res_28_ = lp_tree_GlobalTheory_LiftLevel_vmvBil(v_E_23_, v_inst_24_, v_inst_25_, v_n_26_, v_r_27_);
lean_dec(v_r_27_);
lean_dec(v_n_26_);
lean_dec_ref(v_inst_24_);
return v_res_28_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_RedMFrMapAdjZero(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_FiniteLevelDatumClasses(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_RedMFrMapAdjZero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
