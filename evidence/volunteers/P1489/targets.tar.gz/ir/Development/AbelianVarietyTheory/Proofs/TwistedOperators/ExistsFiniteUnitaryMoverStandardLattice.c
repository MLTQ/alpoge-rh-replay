// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.TwistedOperators.ExistsFiniteUnitaryMoverStandardLattice
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.RedMFrMapAdjZero public import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.AdelicUnitaryExistsWithPrescribedParts public import Development.AbelianVarietyTheory.Proofs.IwasawaDecomposition.ExistsNsmulIntMemLatO public import Development.AbelianVarietyTheory.Proofs.AdelicLatticeProofs.RealIdemMulOfReal public import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.ExistsLatticeRationalVectorsInAdelicTranslate
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lp_mathlib_AddGroupWithOne_toAddGroup___redArg(lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Matrix_map(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_transpose___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_diagonal___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_MoverGlue_glue___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_MoverGlue_glue___redArg___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_MoverGlue_glue___redArg___lam__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_MoverGlue_glue___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_MoverGlue_glue(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_MoverGlue_glue___redArg___lam__0(lean_object* v_00_u03c3_1_, lean_object* v___y_2_){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_apply_1(v_00_u03c3_1_, v___y_2_);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_MoverGlue_glue___redArg___lam__1(lean_object* v_toOne_4_, lean_object* v_x_5_){
_start:
{
lean_inc(v_toOne_4_);
return v_toOne_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_MoverGlue_glue___redArg___lam__1___boxed(lean_object* v_toOne_6_, lean_object* v_x_7_){
_start:
{
lean_object* v_res_8_; 
v_res_8_ = lp_tree_GlobalTheory_MoverGlue_glue___redArg___lam__1(v_toOne_6_, v_x_7_);
lean_dec(v_x_7_);
lean_dec(v_toOne_6_);
return v_res_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_MoverGlue_glue___redArg(lean_object* v_inst_9_, lean_object* v_inst_10_, lean_object* v_00_u03c3_11_, lean_object* v_00_u03b5_12_, lean_object* v_P_13_, lean_object* v_Q_14_, lean_object* v_a_15_, lean_object* v_a_16_){
_start:
{
lean_object* v_toSemiring_17_; lean_object* v___x_18_; lean_object* v_toMul_19_; lean_object* v_toAdd_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v_toAddMonoidWithOne_23_; lean_object* v_toSub_24_; lean_object* v_toOne_25_; lean_object* v___x_26_; lean_object* v___x_27_; lean_object* v_toZero_28_; lean_object* v___x_29_; lean_object* v___f_30_; lean_object* v___x_31_; lean_object* v___f_32_; lean_object* v___x_33_; lean_object* v___x_34_; lean_object* v___x_35_; lean_object* v___x_36_; lean_object* v___x_37_; lean_object* v___x_38_; lean_object* v___x_39_; lean_object* v___x_40_; lean_object* v___x_41_; 
v_toSemiring_17_ = lean_ctor_get(v_inst_9_, 0);
lean_inc_ref_n(v_toSemiring_17_, 2);
v___x_18_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_17_);
v_toMul_19_ = lean_ctor_get(v___x_18_, 0);
lean_inc_n(v_toMul_19_, 3);
v_toAdd_20_ = lean_ctor_get(v___x_18_, 1);
lean_inc_n(v_toAdd_20_, 2);
lean_dec_ref(v___x_18_);
v___x_21_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_inst_9_);
v___x_22_ = lp_mathlib_AddGroupWithOne_toAddGroup___redArg(v___x_21_);
v_toAddMonoidWithOne_23_ = lean_ctor_get(v___x_21_, 1);
lean_inc_ref(v_toAddMonoidWithOne_23_);
lean_dec_ref(v___x_21_);
v_toSub_24_ = lean_ctor_get(v___x_22_, 2);
lean_inc_n(v_toSub_24_, 2);
lean_dec_ref(v___x_22_);
v_toOne_25_ = lean_ctor_get(v_toAddMonoidWithOne_23_, 2);
lean_inc_n(v_toOne_25_, 2);
lean_dec_ref(v_toAddMonoidWithOne_23_);
lean_inc(v_00_u03c3_11_);
lean_inc_n(v_00_u03b5_12_, 2);
v___x_26_ = lean_apply_1(v_00_u03c3_11_, v_00_u03b5_12_);
v___x_27_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_17_);
v_toZero_28_ = lean_ctor_get(v___x_27_, 1);
lean_inc(v_toZero_28_);
lean_dec_ref(v___x_27_);
v___x_29_ = lean_apply_2(v_toSub_24_, v_toOne_25_, v_00_u03b5_12_);
v___f_30_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_MoverGlue_glue___redArg___lam__0), 2, 1);
lean_closure_set(v___f_30_, 0, v_00_u03c3_11_);
v___x_31_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_map), 8, 6);
lean_closure_set(v___x_31_, 0, lean_box(0));
lean_closure_set(v___x_31_, 1, lean_box(0));
lean_closure_set(v___x_31_, 2, lean_box(0));
lean_closure_set(v___x_31_, 3, lean_box(0));
lean_closure_set(v___x_31_, 4, v_Q_14_);
lean_closure_set(v___x_31_, 5, v___f_30_);
v___f_32_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_MoverGlue_glue___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_32_, 0, v_toOne_25_);
lean_inc(v___x_26_);
v___x_33_ = lean_apply_2(v_toSub_24_, v___x_29_, v___x_26_);
lean_inc_n(v_a_16_, 2);
lean_inc_n(v_a_15_, 2);
v___x_34_ = lean_apply_2(v_P_13_, v_a_15_, v_a_16_);
v___x_35_ = lean_apply_2(v_toMul_19_, v_00_u03b5_12_, v___x_34_);
v___x_36_ = lp_mathlib_Matrix_transpose___redArg(v___x_31_, v_a_15_, v_a_16_);
v___x_37_ = lean_apply_2(v_toMul_19_, v___x_26_, v___x_36_);
v___x_38_ = lean_apply_2(v_toAdd_20_, v___x_35_, v___x_37_);
v___x_39_ = lp_mathlib_Matrix_diagonal___redArg(v_inst_10_, v_toZero_28_, v___f_32_, v_a_15_, v_a_16_);
v___x_40_ = lean_apply_2(v_toMul_19_, v___x_33_, v___x_39_);
v___x_41_ = lean_apply_2(v_toAdd_20_, v___x_38_, v___x_40_);
return v___x_41_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_MoverGlue_glue(lean_object* v_R_42_, lean_object* v_inst_43_, lean_object* v_n_44_, lean_object* v_inst_45_, lean_object* v_00_u03c3_46_, lean_object* v_00_u03b5_47_, lean_object* v_P_48_, lean_object* v_Q_49_, lean_object* v_a_50_, lean_object* v_a_51_){
_start:
{
lean_object* v___x_52_; 
v___x_52_ = lp_tree_GlobalTheory_MoverGlue_glue___redArg(v_inst_43_, v_inst_45_, v_00_u03c3_46_, v_00_u03b5_47_, v_P_48_, v_Q_49_, v_a_50_, v_a_51_);
return v___x_52_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_RedMFrMapAdjZero(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_UnitaryExistence_AdelicUnitaryExistsWithPrescribedParts(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ExistsNsmulIntMemLatO(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_AdelicLatticeProofs_RealIdemMulOfReal(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_UnitaryExistence_ExistsLatticeRationalVectorsInAdelicTranslate(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ExistsFiniteUnitaryMoverStandardLattice(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_RedMFrMapAdjZero(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_UnitaryExistence_AdelicUnitaryExistsWithPrescribedParts(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_IwasawaDecomposition_ExistsNsmulIntMemLatO(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_AdelicLatticeProofs_RealIdemMulOfReal(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_UnitaryExistence_ExistsLatticeRationalVectorsInAdelicTranslate(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
