// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.TwistedOperators.HalfLat
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.ConstMemBddAut public import Development.AbelianVarietyTheory.Proofs.DivisorProofs.ExistsIsFinWeil public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.MemHomLatticeIffIntegralMatrixSplitChart public import Development.AbelianVarietyTheory.Proofs.FoundationProofs.MemLatHatIffOfSupport public import Development.AbelianVarietyTheory.Proofs.FoundationProofs.FinPartIdemMulMemIff public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.SplitProjAdeleComponentChartProperties public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.SplitPlaceMatrixCoordinateOnHalf public import Development.AbelianVarietyTheory.Proofs.TwistedOperators.SplitIdempotentPrimeProjectionCorrespondence public import Development.AbelianVarietyTheory.Proofs.SatakeParameters.ExistsMatrixOfIsLattice public import Development.AbelianVarietyTheory.Proofs.FoundationProofs.ExistsIsSplitChartOfBasis public import Development.AbelianVarietyTheory.Proofs.FoundationProofs.IsSplitChartSplitChart public import Development.AbelianVarietyTheory.Proofs.FoundationProofs.ExistsDualFamilyOfIsLattice
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_dotProduct___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* l_List_finRange(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_intMat(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_intMat___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__1(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_intMat(lean_object* v_F_1_, lean_object* v_inst_2_, lean_object* v_inst_3_, lean_object* v_v_4_, lean_object* v_m_5_, lean_object* v_n_6_){
_start:
{
lean_object* v___x_7_; 
v___x_7_ = lean_box(0);
return v___x_7_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_intMat___boxed(lean_object* v_F_8_, lean_object* v_inst_9_, lean_object* v_inst_10_, lean_object* v_v_11_, lean_object* v_m_12_, lean_object* v_n_13_){
_start:
{
lean_object* v_res_14_; 
v_res_14_ = lp_tree_GlobalTheory_SplitIdx_intMat(v_F_8_, v_inst_9_, v_inst_10_, v_v_11_, v_m_12_, v_n_13_);
lean_dec(v_n_13_);
lean_dec(v_m_12_);
lean_dec_ref(v_inst_9_);
return v_res_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__0(lean_object* v_P_15_, lean_object* v___y_16_, lean_object* v_j_17_){
_start:
{
lean_object* v___x_18_; 
v___x_18_ = lean_apply_2(v_P_15_, v___y_16_, v_j_17_);
return v___x_18_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__1(lean_object* v_y_19_, lean_object* v___y_20_, lean_object* v_j_21_){
_start:
{
lean_object* v___x_22_; 
v___x_22_ = lean_apply_2(v_y_19_, v_j_21_, v___y_20_);
return v___x_22_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__2(lean_object* v_P_23_, lean_object* v___x_24_, lean_object* v_toMul_25_, lean_object* v_toAddCommMonoid_26_, lean_object* v_y_27_, lean_object* v___y_28_, lean_object* v___y_29_){
_start:
{
lean_object* v___f_30_; lean_object* v___f_31_; lean_object* v___x_32_; 
v___f_30_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__0), 3, 2);
lean_closure_set(v___f_30_, 0, v_P_23_);
lean_closure_set(v___f_30_, 1, v___y_28_);
v___f_31_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__1), 3, 2);
lean_closure_set(v___f_31_, 0, v_y_27_);
lean_closure_set(v___f_31_, 1, v___y_29_);
v___x_32_ = lp_mathlib_dotProduct___redArg(v___x_24_, v_toMul_25_, v_toAddCommMonoid_26_, v___f_30_, v___f_31_);
return v___x_32_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__2___boxed(lean_object* v_P_33_, lean_object* v___x_34_, lean_object* v_toMul_35_, lean_object* v_toAddCommMonoid_36_, lean_object* v_y_37_, lean_object* v___y_38_, lean_object* v___y_39_){
_start:
{
lean_object* v_res_40_; 
v_res_40_ = lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__2(v_P_33_, v___x_34_, v_toMul_35_, v_toAddCommMonoid_36_, v_y_37_, v___y_38_, v___y_39_);
lean_dec_ref(v_toAddCommMonoid_36_);
return v_res_40_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___redArg(lean_object* v_inst_41_, lean_object* v_m_42_, lean_object* v_P_43_){
_start:
{
lean_object* v_toSemiring_44_; lean_object* v___x_45_; lean_object* v_toMul_46_; lean_object* v_toAddCommMonoid_47_; lean_object* v___x_48_; lean_object* v___f_49_; 
v_toSemiring_44_ = lean_ctor_get(v_inst_41_, 0);
lean_inc_ref_n(v_toSemiring_44_, 2);
lean_dec_ref(v_inst_41_);
v___x_45_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_44_);
v_toMul_46_ = lean_ctor_get(v___x_45_, 0);
lean_inc(v_toMul_46_);
lean_dec_ref(v___x_45_);
v_toAddCommMonoid_47_ = lean_ctor_get(v_toSemiring_44_, 0);
lean_inc_ref(v_toAddCommMonoid_47_);
lean_dec_ref(v_toSemiring_44_);
v___x_48_ = l_List_finRange(v_m_42_);
v___f_49_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_SplitIdx_mulL___redArg___lam__2___boxed), 7, 4);
lean_closure_set(v___f_49_, 0, v_P_43_);
lean_closure_set(v___f_49_, 1, v___x_48_);
lean_closure_set(v___f_49_, 2, v_toMul_46_);
lean_closure_set(v___f_49_, 3, v_toAddCommMonoid_47_);
return v___f_49_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL(lean_object* v_K_50_, lean_object* v_inst_51_, lean_object* v_m_52_, lean_object* v_n_53_, lean_object* v_P_54_){
_start:
{
lean_object* v___x_55_; 
v___x_55_ = lp_tree_GlobalTheory_SplitIdx_mulL___redArg(v_inst_51_, v_m_52_, v_P_54_);
return v___x_55_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_SplitIdx_mulL___boxed(lean_object* v_K_56_, lean_object* v_inst_57_, lean_object* v_m_58_, lean_object* v_n_59_, lean_object* v_P_60_){
_start:
{
lean_object* v_res_61_; 
v_res_61_ = lp_tree_GlobalTheory_SplitIdx_mulL(v_K_56_, v_inst_57_, v_m_58_, v_n_59_, v_P_60_);
lean_dec(v_n_59_);
return v_res_61_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ConstMemBddAut(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_ExistsIsFinWeil(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_MemHomLatticeIffIntegralMatrixSplitChart(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_MemLatHatIffOfSupport(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_FinPartIdemMulMemIff(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_SplitProjAdeleComponentChartProperties(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_SplitPlaceMatrixCoordinateOnHalf(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_SplitIdempotentPrimeProjectionCorrespondence(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_ExistsMatrixOfIsLattice(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_ExistsIsSplitChartOfBasis(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_IsSplitChartSplitChart(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_ExistsDualFamilyOfIsLattice(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_HalfLat(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_ConstMemBddAut(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_DivisorProofs_ExistsIsFinWeil(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_MemHomLatticeIffIntegralMatrixSplitChart(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_MemLatHatIffOfSupport(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_FinPartIdemMulMemIff(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_SplitProjAdeleComponentChartProperties(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_SplitPlaceMatrixCoordinateOnHalf(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_TwistedOperators_SplitIdempotentPrimeProjectionCorrespondence(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_SatakeParameters_ExistsMatrixOfIsLattice(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_ExistsIsSplitChartOfBasis(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_IsSplitChartSplitChart(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_FoundationProofs_ExistsDualFamilyOfIsLattice(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
