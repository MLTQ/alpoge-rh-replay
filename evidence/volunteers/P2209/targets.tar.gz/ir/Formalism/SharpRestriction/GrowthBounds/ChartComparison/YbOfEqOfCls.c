// Lean compiler output
// Module: Formalism.SharpRestriction.GrowthBounds.ChartComparison.YbOfEqOfCls
// Imports: public import Init public meta import Init public import Formalism.SharpRestriction.GrowthBounds.ChartComparison.KerLabelsMu public import Formalism.SharpRestriction.GrowthBounds.ChartComparison.BadQNotOver
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_symm___redArg(lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_ybOf___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_ybOf___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_ybOf(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_ybOf___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_chOfLoc___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_chOfLoc(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_chOfLoc___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_ybOf___redArg(lean_object* v_D_1_, lean_object* v_T_2_, lean_object* v_u_3_, lean_object* v_00_u03bc_4_, lean_object* v_ch_5_, lean_object* v_a_6_){
_start:
{
lean_object* v_R_7_; lean_object* v_yb_8_; lean_object* v_m_9_; lean_object* v___x_10_; lean_object* v___x_11_; lean_object* v___x_12_; lean_object* v___x_13_; 
v_R_7_ = lean_ctor_get(v_D_1_, 0);
v_yb_8_ = lean_ctor_get(v_T_2_, 10);
lean_inc(v_yb_8_);
lean_dec_ref(v_T_2_);
v_m_9_ = lean_ctor_get(v_R_7_, 2);
v___x_10_ = lean_unsigned_to_nat(1u);
v___x_11_ = lean_nat_sub(v_m_9_, v___x_10_);
v___x_12_ = lean_apply_2(v_ch_5_, v___x_11_, v_a_6_);
v___x_13_ = lean_apply_4(v_yb_8_, v_u_3_, v_00_u03bc_4_, lean_box(0), v___x_12_);
return v___x_13_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_ybOf___redArg___boxed(lean_object* v_D_14_, lean_object* v_T_15_, lean_object* v_u_16_, lean_object* v_00_u03bc_17_, lean_object* v_ch_18_, lean_object* v_a_19_){
_start:
{
lean_object* v_res_20_; 
v_res_20_ = lp_tree_Formalism_MainNotions_G_CmpJ_ybOf___redArg(v_D_14_, v_T_15_, v_u_16_, v_00_u03bc_17_, v_ch_18_, v_a_19_);
lean_dec_ref(v_D_14_);
return v_res_20_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_ybOf(lean_object* v_D_21_, lean_object* v_inQ_22_, lean_object* v_T_23_, lean_object* v_u_24_, lean_object* v_00_u03bc_25_, lean_object* v_w_26_, lean_object* v_h_27_, lean_object* v_Fl_28_, lean_object* v_Lv_29_, lean_object* v_ch_30_, lean_object* v_h1_31_, lean_object* v_a_32_){
_start:
{
lean_object* v___x_33_; 
v___x_33_ = lp_tree_Formalism_MainNotions_G_CmpJ_ybOf___redArg(v_D_21_, v_T_23_, v_u_24_, v_00_u03bc_25_, v_ch_30_, v_a_32_);
return v___x_33_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_ybOf___boxed(lean_object* v_D_34_, lean_object* v_inQ_35_, lean_object* v_T_36_, lean_object* v_u_37_, lean_object* v_00_u03bc_38_, lean_object* v_w_39_, lean_object* v_h_40_, lean_object* v_Fl_41_, lean_object* v_Lv_42_, lean_object* v_ch_43_, lean_object* v_h1_44_, lean_object* v_a_45_){
_start:
{
lean_object* v_res_46_; 
v_res_46_ = lp_tree_Formalism_MainNotions_G_CmpJ_ybOf(v_D_34_, v_inQ_35_, v_T_36_, v_u_37_, v_00_u03bc_38_, v_w_39_, v_h_40_, v_Fl_41_, v_Lv_42_, v_ch_43_, v_h1_44_, v_a_45_);
lean_dec_ref(v_Lv_42_);
lean_dec_ref(v_Fl_41_);
lean_dec(v_w_39_);
lean_dec_ref(v_D_34_);
return v_res_46_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_chOfLoc___redArg(lean_object* v_Lp_47_, lean_object* v_a_48_){
_start:
{
lean_object* v_eC_49_; lean_object* v___x_50_; lean_object* v_toFun_51_; lean_object* v___x_52_; lean_object* v_fst_53_; 
v_eC_49_ = lean_ctor_get(v_Lp_47_, 1);
lean_inc_ref(v_eC_49_);
lean_dec_ref(v_Lp_47_);
v___x_50_ = lp_mathlib_Equiv_symm___redArg(v_eC_49_);
v_toFun_51_ = lean_ctor_get(v___x_50_, 0);
lean_inc(v_toFun_51_);
lean_dec_ref(v___x_50_);
v___x_52_ = lean_apply_1(v_toFun_51_, v_a_48_);
v_fst_53_ = lean_ctor_get(v___x_52_, 0);
lean_inc(v_fst_53_);
lean_dec_ref(v___x_52_);
return v_fst_53_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_chOfLoc(lean_object* v_D_54_, lean_object* v_inQ_55_, lean_object* v_T_56_, lean_object* v_u_57_, lean_object* v_00_u03bc_58_, lean_object* v_p_59_, lean_object* v_G_60_, lean_object* v_j_61_, lean_object* v_Lp_62_, lean_object* v_a_63_){
_start:
{
lean_object* v___x_64_; 
v___x_64_ = lp_tree_Formalism_MainNotions_G_CmpJ_chOfLoc___redArg(v_Lp_62_, v_a_63_);
return v___x_64_;
}
}
LEAN_EXPORT lean_object* lp_tree_Formalism_MainNotions_G_CmpJ_chOfLoc___boxed(lean_object* v_D_65_, lean_object* v_inQ_66_, lean_object* v_T_67_, lean_object* v_u_68_, lean_object* v_00_u03bc_69_, lean_object* v_p_70_, lean_object* v_G_71_, lean_object* v_j_72_, lean_object* v_Lp_73_, lean_object* v_a_74_){
_start:
{
lean_object* v_res_75_; 
v_res_75_ = lp_tree_Formalism_MainNotions_G_CmpJ_chOfLoc(v_D_65_, v_inQ_66_, v_T_67_, v_u_68_, v_00_u03bc_69_, v_p_70_, v_G_71_, v_j_72_, v_Lp_73_, v_a_74_);
lean_dec(v_j_72_);
lean_dec_ref(v_G_71_);
lean_dec(v_p_70_);
lean_dec(v_00_u03bc_69_);
lean_dec(v_u_68_);
lean_dec_ref(v_T_67_);
lean_dec_ref(v_D_65_);
return v_res_75_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_GrowthBounds_ChartComparison_KerLabelsMu(uint8_t builtin);
lean_object* initialize_tree_Formalism_SharpRestriction_GrowthBounds_ChartComparison_BadQNotOver(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Formalism_SharpRestriction_GrowthBounds_ChartComparison_YbOfEqOfCls(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_GrowthBounds_ChartComparison_KerLabelsMu(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Formalism_SharpRestriction_GrowthBounds_ChartComparison_BadQNotOver(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
