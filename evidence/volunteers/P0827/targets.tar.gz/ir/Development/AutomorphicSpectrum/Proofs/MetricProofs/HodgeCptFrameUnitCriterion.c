// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.HodgeCptFrameUnitCriterion
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Proofs.MetricProofs.ColFlags public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FunctionFieldRatioGenerators public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameMatrixChartRatios public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.IsArithVarOfBlockAlgebraic public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.GenericFlagTrdegFormula
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_refl(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_yv_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_yv_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_yv_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___lam__0(lean_object* v_c_1_, lean_object* v_s_2_, lean_object* v_00_u03c6_3_, lean_object* v_j_4_, lean_object* v_l_5_){
_start:
{
lean_object* v___x_6_; lean_object* v___x_7_; 
lean_inc_ref(v_s_2_);
v___x_6_ = lean_apply_2(v_c_1_, v_s_2_, v_l_5_);
v___x_7_ = lean_apply_3(v_00_u03c6_3_, v_s_2_, v_j_4_, v___x_6_);
return v___x_7_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___closed__0(void){
_start:
{
lean_object* v___x_8_; 
v___x_8_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg(lean_object* v_00_u03c6_9_, lean_object* v_c_10_, lean_object* v_s_11_, lean_object* v_a_12_, lean_object* v_a_13_){
_start:
{
lean_object* v___x_14_; lean_object* v_toFun_15_; lean_object* v___f_16_; lean_object* v___x_17_; 
v___x_14_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___closed__0, &lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___closed__0);
v_toFun_15_ = lean_ctor_get(v___x_14_, 0);
v___f_16_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___lam__0), 5, 3);
lean_closure_set(v___f_16_, 0, v_c_10_);
lean_closure_set(v___f_16_, 1, v_s_11_);
lean_closure_set(v___f_16_, 2, v_00_u03c6_9_);
lean_inc(v_toFun_15_);
v___x_17_ = lean_apply_3(v_toFun_15_, v___f_16_, v_a_12_, v_a_13_);
return v___x_17_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals(lean_object* v_00_u03a8_18_, lean_object* v_p_19_, lean_object* v_q_20_, lean_object* v_00_u03a9_21_, lean_object* v_inst_22_, lean_object* v_E_23_, lean_object* v_inst_24_, lean_object* v_inst_25_, lean_object* v_n_26_, lean_object* v_00_u03c6_27_, lean_object* v_c_28_, lean_object* v_s_29_, lean_object* v_a_30_, lean_object* v_a_31_){
_start:
{
lean_object* v___x_32_; lean_object* v_toFun_33_; lean_object* v___f_34_; lean_object* v___x_35_; 
v___x_32_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___closed__0, &lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___closed__0);
v_toFun_33_ = lean_ctor_get(v___x_32_, 0);
v___f_34_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___redArg___lam__0), 5, 3);
lean_closure_set(v___f_34_, 0, v_c_28_);
lean_closure_set(v___f_34_, 1, v_s_29_);
lean_closure_set(v___f_34_, 2, v_00_u03c6_27_);
lean_inc(v_toFun_33_);
v___x_35_ = lean_apply_3(v_toFun_33_, v___f_34_, v_a_30_, v_a_31_);
return v___x_35_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals___boxed(lean_object* v_00_u03a8_36_, lean_object* v_p_37_, lean_object* v_q_38_, lean_object* v_00_u03a9_39_, lean_object* v_inst_40_, lean_object* v_E_41_, lean_object* v_inst_42_, lean_object* v_inst_43_, lean_object* v_n_44_, lean_object* v_00_u03c6_45_, lean_object* v_c_46_, lean_object* v_s_47_, lean_object* v_a_48_, lean_object* v_a_49_){
_start:
{
lean_object* v_res_50_; 
v_res_50_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_vals(v_00_u03a8_36_, v_p_37_, v_q_38_, v_00_u03a9_39_, v_inst_40_, v_E_41_, v_inst_42_, v_inst_43_, v_n_44_, v_00_u03c6_45_, v_c_46_, v_s_47_, v_a_48_, v_a_49_);
lean_dec_ref(v_n_44_);
lean_dec(v_inst_43_);
lean_dec_ref(v_inst_42_);
lean_dec_ref(v_inst_40_);
lean_dec(v_q_38_);
lean_dec(v_p_37_);
return v_res_50_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf___redArg___lam__0(lean_object* v_j_51_, lean_object* v_val_52_, lean_object* v___y_53_){
_start:
{
lean_object* v_snd_54_; lean_object* v___x_55_; 
v_snd_54_ = lean_ctor_get(v_j_51_, 1);
lean_inc(v_snd_54_);
lean_dec_ref(v_j_51_);
v___x_55_ = lean_apply_2(v_snd_54_, v_val_52_, v___y_53_);
return v___x_55_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf___redArg(lean_object* v_j_56_, lean_object* v_x_57_){
_start:
{
if (lean_obj_tag(v_x_57_) == 0)
{
lean_object* v_val_58_; lean_object* v_fst_59_; lean_object* v___x_60_; 
v_val_58_ = lean_ctor_get(v_x_57_, 0);
lean_inc(v_val_58_);
lean_dec_ref_known(v_x_57_, 1);
v_fst_59_ = lean_ctor_get(v_j_56_, 0);
lean_inc(v_fst_59_);
lean_dec_ref(v_j_56_);
v___x_60_ = lean_apply_1(v_fst_59_, v_val_58_);
return v___x_60_;
}
else
{
lean_object* v_val_61_; lean_object* v___f_62_; 
v_val_61_ = lean_ctor_get(v_x_57_, 0);
lean_inc(v_val_61_);
lean_dec_ref_known(v_x_57_, 1);
v___f_62_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf___redArg___lam__0), 3, 2);
lean_closure_set(v___f_62_, 0, v_j_56_);
lean_closure_set(v___f_62_, 1, v_val_61_);
return v___f_62_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf(lean_object* v_00_u03a8_63_, lean_object* v_p_64_, lean_object* v_q_65_, lean_object* v_n_66_, lean_object* v_K_u2080_67_, lean_object* v_J_u2080_68_, lean_object* v_j_69_, lean_object* v_x_70_){
_start:
{
lean_object* v___x_71_; 
v___x_71_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf___redArg(v_j_69_, v_x_70_);
return v___x_71_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf___boxed(lean_object* v_00_u03a8_72_, lean_object* v_p_73_, lean_object* v_q_74_, lean_object* v_n_75_, lean_object* v_K_u2080_76_, lean_object* v_J_u2080_77_, lean_object* v_j_78_, lean_object* v_x_79_){
_start:
{
lean_object* v_res_80_; 
v_res_80_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf(v_00_u03a8_72_, v_p_73_, v_q_74_, v_n_75_, v_K_u2080_76_, v_J_u2080_77_, v_j_78_, v_x_79_);
lean_dec_ref(v_n_75_);
lean_dec(v_q_74_);
lean_dec(v_p_73_);
return v_res_80_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_yv_match__1_splitter___redArg(lean_object* v_x_81_, lean_object* v_h__1_82_, lean_object* v_h__2_83_){
_start:
{
lean_object* v_fst_84_; 
v_fst_84_ = lean_ctor_get(v_x_81_, 0);
lean_inc(v_fst_84_);
if (lean_obj_tag(v_fst_84_) == 0)
{
lean_object* v_snd_85_; lean_object* v_val_86_; lean_object* v___x_87_; 
lean_dec(v_h__2_83_);
v_snd_85_ = lean_ctor_get(v_x_81_, 1);
lean_inc(v_snd_85_);
lean_dec_ref(v_x_81_);
v_val_86_ = lean_ctor_get(v_fst_84_, 0);
lean_inc(v_val_86_);
lean_dec_ref_known(v_fst_84_, 1);
v___x_87_ = lean_apply_2(v_h__1_82_, v_val_86_, v_snd_85_);
return v___x_87_;
}
else
{
lean_object* v_snd_88_; lean_object* v_val_89_; lean_object* v___x_90_; 
lean_dec(v_h__1_82_);
v_snd_88_ = lean_ctor_get(v_x_81_, 1);
lean_inc(v_snd_88_);
lean_dec_ref(v_x_81_);
v_val_89_ = lean_ctor_get(v_fst_84_, 0);
lean_inc(v_val_89_);
lean_dec_ref_known(v_fst_84_, 1);
v___x_90_ = lean_apply_2(v_h__2_83_, v_val_89_, v_snd_88_);
return v___x_90_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_yv_match__1_splitter(lean_object* v_00_u03a8_91_, lean_object* v_p_92_, lean_object* v_q_93_, lean_object* v_n_94_, lean_object* v_K_u2080_95_, lean_object* v_J_u2080_96_, lean_object* v_motive_97_, lean_object* v_x_98_, lean_object* v_h__1_99_, lean_object* v_h__2_100_){
_start:
{
lean_object* v_fst_101_; 
v_fst_101_ = lean_ctor_get(v_x_98_, 0);
lean_inc(v_fst_101_);
if (lean_obj_tag(v_fst_101_) == 0)
{
lean_object* v_snd_102_; lean_object* v_val_103_; lean_object* v___x_104_; 
lean_dec(v_h__2_100_);
v_snd_102_ = lean_ctor_get(v_x_98_, 1);
lean_inc(v_snd_102_);
lean_dec_ref(v_x_98_);
v_val_103_ = lean_ctor_get(v_fst_101_, 0);
lean_inc(v_val_103_);
lean_dec_ref_known(v_fst_101_, 1);
v___x_104_ = lean_apply_2(v_h__1_99_, v_val_103_, v_snd_102_);
return v___x_104_;
}
else
{
lean_object* v_snd_105_; lean_object* v_val_106_; lean_object* v___x_107_; 
lean_dec(v_h__1_99_);
v_snd_105_ = lean_ctor_get(v_x_98_, 1);
lean_inc(v_snd_105_);
lean_dec_ref(v_x_98_);
v_val_106_ = lean_ctor_get(v_fst_101_, 0);
lean_inc(v_val_106_);
lean_dec_ref_known(v_fst_101_, 1);
v___x_107_ = lean_apply_2(v_h__2_100_, v_val_106_, v_snd_105_);
return v___x_107_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_yv_match__1_splitter___boxed(lean_object* v_00_u03a8_108_, lean_object* v_p_109_, lean_object* v_q_110_, lean_object* v_n_111_, lean_object* v_K_u2080_112_, lean_object* v_J_u2080_113_, lean_object* v_motive_114_, lean_object* v_x_115_, lean_object* v_h__1_116_, lean_object* v_h__2_117_){
_start:
{
lean_object* v_res_118_; 
v_res_118_ = lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_yv_match__1_splitter(v_00_u03a8_108_, v_p_109_, v_q_110_, v_n_111_, v_K_u2080_112_, v_J_u2080_113_, v_motive_114_, v_x_115_, v_h__1_116_, v_h__2_117_);
lean_dec_ref(v_n_111_);
lean_dec(v_q_110_);
lean_dec(v_p_109_);
return v_res_118_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf_match__1_splitter___redArg(lean_object* v_x_119_, lean_object* v_h__1_120_, lean_object* v_h__2_121_){
_start:
{
if (lean_obj_tag(v_x_119_) == 0)
{
lean_object* v_val_122_; lean_object* v___x_123_; 
lean_dec(v_h__2_121_);
v_val_122_ = lean_ctor_get(v_x_119_, 0);
lean_inc(v_val_122_);
lean_dec_ref_known(v_x_119_, 1);
v___x_123_ = lean_apply_1(v_h__1_120_, v_val_122_);
return v___x_123_;
}
else
{
lean_object* v_val_124_; lean_object* v___x_125_; 
lean_dec(v_h__1_120_);
v_val_124_ = lean_ctor_get(v_x_119_, 0);
lean_inc(v_val_124_);
lean_dec_ref_known(v_x_119_, 1);
v___x_125_ = lean_apply_1(v_h__2_121_, v_val_124_);
return v___x_125_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf_match__1_splitter(lean_object* v_00_u03a8_126_, lean_object* v_p_127_, lean_object* v_q_128_, lean_object* v_K_u2080_129_, lean_object* v_motive_130_, lean_object* v_x_131_, lean_object* v_h__1_132_, lean_object* v_h__2_133_){
_start:
{
if (lean_obj_tag(v_x_131_) == 0)
{
lean_object* v_val_134_; lean_object* v___x_135_; 
lean_dec(v_h__2_133_);
v_val_134_ = lean_ctor_get(v_x_131_, 0);
lean_inc(v_val_134_);
lean_dec_ref_known(v_x_131_, 1);
v___x_135_ = lean_apply_1(v_h__1_132_, v_val_134_);
return v___x_135_;
}
else
{
lean_object* v_val_136_; lean_object* v___x_137_; 
lean_dec(v_h__1_132_);
v_val_136_ = lean_ctor_get(v_x_131_, 0);
lean_inc(v_val_136_);
lean_dec_ref_known(v_x_131_, 1);
v___x_137_ = lean_apply_1(v_h__2_133_, v_val_136_);
return v___x_137_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf_match__1_splitter___boxed(lean_object* v_00_u03a8_138_, lean_object* v_p_139_, lean_object* v_q_140_, lean_object* v_K_u2080_141_, lean_object* v_motive_142_, lean_object* v_x_143_, lean_object* v_h__1_144_, lean_object* v_h__2_145_){
_start:
{
lean_object* v_res_146_; 
v_res_146_ = lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_DimY_chartOf_match__1_splitter(v_00_u03a8_138_, v_p_139_, v_q_140_, v_K_u2080_141_, v_motive_142_, v_x_143_, v_h__1_144_, v_h__2_145_);
lean_dec(v_q_140_);
lean_dec(v_p_139_);
return v_res_146_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FunctionFieldRatioGenerators(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FrameMatrixChartRatios(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_IsArithVarOfBlockAlgebraic(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_GenericFlagTrdegFormula(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameUnitCriterion(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FunctionFieldRatioGenerators(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FrameMatrixChartRatios(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_IsArithVarOfBlockAlgebraic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_GenericFlagTrdegFormula(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
