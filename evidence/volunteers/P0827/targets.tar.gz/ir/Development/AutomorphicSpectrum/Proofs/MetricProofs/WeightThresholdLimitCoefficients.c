// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.WeightThresholdLimitCoefficients
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Definitions.MetricPeriods.VolumeInputs public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.MoriwakiSt public import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.RootModelArithIntersectionFormula public import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.RootModelLogIntegralFormula public import Development.AutomorphicSpectrum.Proofs.DivisibilityProofs.RootModelCurveDegreeNef public import Development.WeilBound.CoreStatements.FlagImmersions.RootModelLineSemipositive
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_VolumeInputs(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ArakelovGeometry_MoriwakiSt(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_DivisibilityProofs_RootModelArithIntersectionFormula(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_DivisibilityProofs_RootModelLogIntegralFormula(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_DivisibilityProofs_RootModelCurveDegreeNef(uint8_t builtin);
lean_object* initialize_tree_Development_WeilBound_CoreStatements_FlagImmersions_RootModelLineSemipositive(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_WeightThresholdLimitCoefficients(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_VolumeInputs(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ArakelovGeometry_MoriwakiSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_DivisibilityProofs_RootModelArithIntersectionFormula(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_DivisibilityProofs_RootModelLogIntegralFormula(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_DivisibilityProofs_RootModelCurveDegreeNef(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_WeilBound_CoreStatements_FlagImmersions_RootModelLineSemipositive(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
