// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.YvEqSumMinorsGMat
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Proofs.MetricProofs.ColFlags public import Development.AutomorphicSpectrum.Proofs.MetricProofs.BlockDiagonalMinorVanishing
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_YvEqSumMinorsGMat_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_coefF_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_YvEqSumMinorsGMat_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_coefF_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_YvEqSumMinorsGMat_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_coefF_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_YvEqSumMinorsGMat_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_coefF_match__1_splitter___redArg(lean_object* v_x_1_, lean_object* v_x_2_, lean_object* v_h__1_3_, lean_object* v_h__2_4_){
_start:
{
lean_object* v_fst_5_; 
v_fst_5_ = lean_ctor_get(v_x_1_, 0);
lean_inc(v_fst_5_);
if (lean_obj_tag(v_fst_5_) == 0)
{
lean_object* v_snd_6_; lean_object* v_val_7_; lean_object* v___x_8_; 
lean_dec(v_h__2_4_);
v_snd_6_ = lean_ctor_get(v_x_1_, 1);
lean_inc(v_snd_6_);
lean_dec_ref(v_x_1_);
v_val_7_ = lean_ctor_get(v_fst_5_, 0);
lean_inc(v_val_7_);
lean_dec_ref_known(v_fst_5_, 1);
v___x_8_ = lean_apply_3(v_h__1_3_, v_val_7_, v_snd_6_, v_x_2_);
return v___x_8_;
}
else
{
lean_object* v_snd_9_; lean_object* v_val_10_; lean_object* v___x_11_; 
lean_dec(v_h__1_3_);
v_snd_9_ = lean_ctor_get(v_x_1_, 1);
lean_inc(v_snd_9_);
lean_dec_ref(v_x_1_);
v_val_10_ = lean_ctor_get(v_fst_5_, 0);
lean_inc(v_val_10_);
lean_dec_ref_known(v_fst_5_, 1);
v___x_11_ = lean_apply_3(v_h__2_4_, v_val_10_, v_snd_9_, v_x_2_);
return v___x_11_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_YvEqSumMinorsGMat_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_coefF_match__1_splitter(lean_object* v_00_u03a8_12_, lean_object* v_p_13_, lean_object* v_q_14_, lean_object* v_n_15_, lean_object* v_K_u2080_16_, lean_object* v_J_u2080_17_, lean_object* v_motive_18_, lean_object* v_x_19_, lean_object* v_x_20_, lean_object* v_h__1_21_, lean_object* v_h__2_22_){
_start:
{
lean_object* v_fst_23_; 
v_fst_23_ = lean_ctor_get(v_x_19_, 0);
lean_inc(v_fst_23_);
if (lean_obj_tag(v_fst_23_) == 0)
{
lean_object* v_snd_24_; lean_object* v_val_25_; lean_object* v___x_26_; 
lean_dec(v_h__2_22_);
v_snd_24_ = lean_ctor_get(v_x_19_, 1);
lean_inc(v_snd_24_);
lean_dec_ref(v_x_19_);
v_val_25_ = lean_ctor_get(v_fst_23_, 0);
lean_inc(v_val_25_);
lean_dec_ref_known(v_fst_23_, 1);
v___x_26_ = lean_apply_3(v_h__1_21_, v_val_25_, v_snd_24_, v_x_20_);
return v___x_26_;
}
else
{
lean_object* v_snd_27_; lean_object* v_val_28_; lean_object* v___x_29_; 
lean_dec(v_h__1_21_);
v_snd_27_ = lean_ctor_get(v_x_19_, 1);
lean_inc(v_snd_27_);
lean_dec_ref(v_x_19_);
v_val_28_ = lean_ctor_get(v_fst_23_, 0);
lean_inc(v_val_28_);
lean_dec_ref_known(v_fst_23_, 1);
v___x_29_ = lean_apply_3(v_h__2_22_, v_val_28_, v_snd_27_, v_x_20_);
return v___x_29_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_YvEqSumMinorsGMat_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_coefF_match__1_splitter___boxed(lean_object* v_00_u03a8_30_, lean_object* v_p_31_, lean_object* v_q_32_, lean_object* v_n_33_, lean_object* v_K_u2080_34_, lean_object* v_J_u2080_35_, lean_object* v_motive_36_, lean_object* v_x_37_, lean_object* v_x_38_, lean_object* v_h__1_39_, lean_object* v_h__2_40_){
_start:
{
lean_object* v_res_41_; 
v_res_41_ = lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_YvEqSumMinorsGMat_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_coefF_match__1_splitter(v_00_u03a8_30_, v_p_31_, v_q_32_, v_n_33_, v_K_u2080_34_, v_J_u2080_35_, v_motive_36_, v_x_37_, v_x_38_, v_h__1_39_, v_h__2_40_);
lean_dec_ref(v_n_33_);
lean_dec(v_q_32_);
lean_dec(v_p_31_);
return v_res_41_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_BlockDiagonalMinorVanishing(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_YvEqSumMinorsGMat(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_BlockDiagonalMinorVanishing(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
