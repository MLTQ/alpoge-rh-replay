// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.MinorIJMap
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Definitions.MetricPeriods.Pull1 public import Development.AutomorphicSpectrum.Definitions.MetricPeriods.IsPeriodOn public import Development.AutomorphicSpectrum.Proofs.MetricProofs.IsImg public import Development.AutomorphicSpectrum.Proofs.MetricProofs.AevalNeZeroOfNotMem public import Development.AutomorphicSpectrum.Proofs.MetricProofs.IsValueAtOfTorus public import Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsBlkCover public import GroundTheory.HeightsAndTheta.Heights.Intersections.PtsOverPt
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_CovMap_LocImg_regRing(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_CovMap_LocImg_regRing___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_CovMap_LocImg_regRing(lean_object* v_K_1_, lean_object* v_inst_2_, lean_object* v_00_u03b9_3_, lean_object* v_inst_4_, lean_object* v_00_u03a9_5_, lean_object* v_inst_6_, lean_object* v_x_7_, lean_object* v_z_8_){
_start:
{
lean_object* v___x_9_; 
v___x_9_ = lean_box(0);
return v___x_9_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_CovMap_LocImg_regRing___boxed(lean_object* v_K_10_, lean_object* v_inst_11_, lean_object* v_00_u03b9_12_, lean_object* v_inst_13_, lean_object* v_00_u03a9_14_, lean_object* v_inst_15_, lean_object* v_x_16_, lean_object* v_z_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_CovMap_LocImg_regRing(v_K_10_, v_inst_11_, v_00_u03b9_12_, v_inst_13_, v_00_u03a9_14_, v_inst_15_, v_x_16_, v_z_17_);
lean_dec_ref(v_z_17_);
lean_dec(v_x_16_);
lean_dec_ref(v_inst_15_);
lean_dec(v_inst_13_);
lean_dec(v_inst_11_);
return v_res_18_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_Pull1(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_IsPeriodOn(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsImg(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_AevalNeZeroOfNotMem(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsValueAtOfTorus(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ExistsBlkCover(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_Intersections_PtsOverPt(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_MinorIJMap(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_Pull1(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_IsPeriodOn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsImg(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_AevalNeZeroOfNotMem(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsValueAtOfTorus(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ExistsBlkCover(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_Intersections_PtsOverPt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
