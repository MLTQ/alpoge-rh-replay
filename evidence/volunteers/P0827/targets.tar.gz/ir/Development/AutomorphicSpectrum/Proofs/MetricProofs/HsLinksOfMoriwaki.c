// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.HsLinksOfMoriwaki
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Statements.GeometryStatements.ZhangDimensionPushDownGrassmannianHeightBounds public import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.ArakelovGeometry.MoriwakiSt public import GroundTheory.HeightsAndTheta.Heights.SemipositiveHeights.Imports public import GroundTheory.HeightsAndTheta.Heights.SemipositiveHeights.OfMoriwakiHS public import GroundTheory.HeightsAndTheta.Heights.SemipositiveHeights.ImportsBis public import GroundTheory.HeightsAndTheta.Heights.SemipositiveHeights.BigLineBundleMoriwaki public import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.PZhangLowerX public import GroundTheory.HeightsAndTheta.Heights.HodgeLowerBound.RingKrullDimLocalizationInt
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_ZhangDimensionPushDownGrassmannianHeightBounds(uint8_t builtin);
lean_object* initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ArakelovGeometry_MoriwakiSt(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_SemipositiveHeights_Imports(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_SemipositiveHeights_OfMoriwakiHS(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_SemipositiveHeights_ImportsBis(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_SemipositiveHeights_BigLineBundleMoriwaki(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_HodgeLowerBound_PZhangLowerX(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_HodgeLowerBound_RingKrullDimLocalizationInt(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_HsLinksOfMoriwaki(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_ZhangDimensionPushDownGrassmannianHeightBounds(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_ReciprocityTheory_ReductiveGroups_ArithmeticGeometry_ArakelovGeometry_MoriwakiSt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_SemipositiveHeights_Imports(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_SemipositiveHeights_OfMoriwakiHS(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_SemipositiveHeights_ImportsBis(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_SemipositiveHeights_BigLineBundleMoriwaki(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_HodgeLowerBound_PZhangLowerX(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_HodgeLowerBound_RingKrullDimLocalizationInt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
