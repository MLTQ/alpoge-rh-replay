// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsSymplecticBasisPrincipalPolarizationStatement
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Proofs.MetricProofs.ExistsSymplecticBasisPrincipalPolarization public import Development.AutomorphicSpectrum.Definitions.GlobalGeometry.IsThetaMeanSquareNorm public import Development.AutomorphicSpectrum.Statements.GeometryStatements.ZhangDimensionPushDownGrassmannianHeightBounds public import GroundTheory.HeightsAndTheta.Heights.KernelsLattice public import GroundTheory.HeightsAndTheta.Heights.LatticeLemmas.StatementsBundles public import GroundTheory.HeightsAndTheta.Heights.KernelsMatrix public import GroundTheory.HeightsAndTheta.Heights.HeightKernels.AssemblyAnalytic public import GroundTheory.HeightsAndTheta.Heights.FactorialBounds.Assembly public import Development.AbelianVarietyTheory.Proofs.CuspFormEvaluations.HasSumPolyDerivMulProdAddMatrix public import Development.AbelianVarietyTheory.Proofs.UnitaryExistence.ExistsFundamentalDomainMeanNormSqThetaChar public import Development.AbelianVarietyTheory.Proofs.ToricGeometry.IsUnitOfLagrangian public import GroundTheory.HeightsAndTheta.Heights.HeightKernels.CoordSiegel public import Development.AbelianVarietyTheory.Proofs.CovolumeBounds.DualRestrictSurjectiveOfIsTorsionFreeQuotient
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ExistsSymplecticBasisPrincipalPolarization(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_IsThetaMeanSquareNorm(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_ZhangDimensionPushDownGrassmannianHeightBounds(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_KernelsLattice(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_LatticeLemmas_StatementsBundles(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_KernelsMatrix(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_HeightKernels_AssemblyAnalytic(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_FactorialBounds_Assembly(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_HasSumPolyDerivMulProdAddMatrix(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_UnitaryExistence_ExistsFundamentalDomainMeanNormSqThetaChar(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_ToricGeometry_IsUnitOfLagrangian(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_HeightKernels_CoordSiegel(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_CovolumeBounds_DualRestrictSurjectiveOfIsTorsionFreeQuotient(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ExistsSymplecticBasisPrincipalPolarizationStatement(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ExistsSymplecticBasisPrincipalPolarization(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_GlobalGeometry_IsThetaMeanSquareNorm(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Statements_GeometryStatements_ZhangDimensionPushDownGrassmannianHeightBounds(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_KernelsLattice(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_LatticeLemmas_StatementsBundles(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_KernelsMatrix(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_HeightKernels_AssemblyAnalytic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_FactorialBounds_Assembly(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_CuspFormEvaluations_HasSumPolyDerivMulProdAddMatrix(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_UnitaryExistence_ExistsFundamentalDomainMeanNormSqThetaChar(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_ToricGeometry_IsUnitOfLagrangian(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_HeightKernels_CoordSiegel(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Proofs_CovolumeBounds_DualRestrictSurjectiveOfIsTorsionFreeQuotient(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
