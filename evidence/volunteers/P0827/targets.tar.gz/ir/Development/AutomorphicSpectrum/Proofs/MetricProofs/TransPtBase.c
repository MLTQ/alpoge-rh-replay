// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.TransPtBase
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Definitions.MetricPeriods.Pull1 public import Development.AutomorphicSpectrum.Definitions.MetricPeriods.IsPeriodOn public import Development.AutomorphicSpectrum.Proofs.MetricProofs.IsImg public import GroundTheory.HeightsAndTheta.Heights.Intersections.PtsOverPt public import Development.AutomorphicSpectrum.Proofs.MetricProofs.AevalNeZeroOfNotMem public import Development.AutomorphicSpectrum.Proofs.MetricProofs.IsValueAtOfTorus public import GroundTheory.HeightsAndTheta.Heights.HilbertSamuel.PCoordArithOfFnField public import Development.AutomorphicSpectrum.Proofs.MetricProofs.BlockDiagonalMinorVanishingStatement public import Development.AutomorphicSpectrum.Proofs.MetricProofs.FlagModelBaseProjectionPointsStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_CovGraph_pairV___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_CovGraph_pairV(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_CovGraph_pairV___redArg(lean_object* v_a_1_, lean_object* v_b_2_, lean_object* v_x_3_){
_start:
{
lean_object* v_fst_4_; 
v_fst_4_ = lean_ctor_get(v_x_3_, 0);
lean_inc(v_fst_4_);
if (lean_obj_tag(v_fst_4_) == 0)
{
lean_object* v_snd_5_; lean_object* v___x_7_; uint8_t v_isShared_8_; uint8_t v_isSharedCheck_14_; 
lean_dec(v_b_2_);
v_snd_5_ = lean_ctor_get(v_x_3_, 1);
v_isSharedCheck_14_ = !lean_is_exclusive(v_x_3_);
if (v_isSharedCheck_14_ == 0)
{
lean_object* v_unused_15_; 
v_unused_15_ = lean_ctor_get(v_x_3_, 0);
lean_dec(v_unused_15_);
v___x_7_ = v_x_3_;
v_isShared_8_ = v_isSharedCheck_14_;
goto v_resetjp_6_;
}
else
{
lean_inc(v_snd_5_);
lean_dec(v_x_3_);
v___x_7_ = lean_box(0);
v_isShared_8_ = v_isSharedCheck_14_;
goto v_resetjp_6_;
}
v_resetjp_6_:
{
lean_object* v_val_9_; lean_object* v___x_11_; 
v_val_9_ = lean_ctor_get(v_fst_4_, 0);
lean_inc(v_val_9_);
lean_dec_ref_known(v_fst_4_, 1);
if (v_isShared_8_ == 0)
{
lean_ctor_set(v___x_7_, 0, v_val_9_);
v___x_11_ = v___x_7_;
goto v_reusejp_10_;
}
else
{
lean_object* v_reuseFailAlloc_13_; 
v_reuseFailAlloc_13_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_13_, 0, v_val_9_);
lean_ctor_set(v_reuseFailAlloc_13_, 1, v_snd_5_);
v___x_11_ = v_reuseFailAlloc_13_;
goto v_reusejp_10_;
}
v_reusejp_10_:
{
lean_object* v___x_12_; 
v___x_12_ = lean_apply_1(v_a_1_, v___x_11_);
return v___x_12_;
}
}
}
else
{
lean_object* v_snd_16_; lean_object* v___x_18_; uint8_t v_isShared_19_; uint8_t v_isSharedCheck_25_; 
lean_dec(v_a_1_);
v_snd_16_ = lean_ctor_get(v_x_3_, 1);
v_isSharedCheck_25_ = !lean_is_exclusive(v_x_3_);
if (v_isSharedCheck_25_ == 0)
{
lean_object* v_unused_26_; 
v_unused_26_ = lean_ctor_get(v_x_3_, 0);
lean_dec(v_unused_26_);
v___x_18_ = v_x_3_;
v_isShared_19_ = v_isSharedCheck_25_;
goto v_resetjp_17_;
}
else
{
lean_inc(v_snd_16_);
lean_dec(v_x_3_);
v___x_18_ = lean_box(0);
v_isShared_19_ = v_isSharedCheck_25_;
goto v_resetjp_17_;
}
v_resetjp_17_:
{
lean_object* v_val_20_; lean_object* v___x_22_; 
v_val_20_ = lean_ctor_get(v_fst_4_, 0);
lean_inc(v_val_20_);
lean_dec_ref_known(v_fst_4_, 1);
if (v_isShared_19_ == 0)
{
lean_ctor_set(v___x_18_, 0, v_val_20_);
v___x_22_ = v___x_18_;
goto v_reusejp_21_;
}
else
{
lean_object* v_reuseFailAlloc_24_; 
v_reuseFailAlloc_24_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_24_, 0, v_val_20_);
lean_ctor_set(v_reuseFailAlloc_24_, 1, v_snd_16_);
v___x_22_ = v_reuseFailAlloc_24_;
goto v_reusejp_21_;
}
v_reusejp_21_:
{
lean_object* v___x_23_; 
v___x_23_ = lean_apply_1(v_b_2_, v___x_22_);
return v___x_23_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_CovGraph_pairV(lean_object* v_K_27_, lean_object* v_00_u03b9_28_, lean_object* v_K_x27_29_, lean_object* v_00_u03b9_x27_30_, lean_object* v_R_31_, lean_object* v_a_32_, lean_object* v_b_33_, lean_object* v_x_34_){
_start:
{
lean_object* v___x_35_; 
v___x_35_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_CovGraph_pairV___redArg(v_a_32_, v_b_33_, v_x_34_);
return v___x_35_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_Pull1(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_IsPeriodOn(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsImg(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_Intersections_PtsOverPt(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_AevalNeZeroOfNotMem(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsValueAtOfTorus(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_HilbertSamuel_PCoordArithOfFnField(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_BlockDiagonalMinorVanishingStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_FlagModelBaseProjectionPointsStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_TransPtBase(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_Pull1(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_IsPeriodOn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsImg(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_Intersections_PtsOverPt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_AevalNeZeroOfNotMem(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsValueAtOfTorus(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_HilbertSamuel_PCoordArithOfFnField(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_BlockDiagonalMinorVanishingStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_FlagModelBaseProjectionPointsStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
