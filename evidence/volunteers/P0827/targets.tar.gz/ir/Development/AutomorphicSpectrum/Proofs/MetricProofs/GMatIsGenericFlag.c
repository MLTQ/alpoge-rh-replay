// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.GMatIsGenericFlag
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Proofs.MetricProofs.ColFlags
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_add(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_GenMat_loc___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_GenMat_loc___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_GenMat_loc(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_GenMat_loc___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_GenMat_loc___redArg(lean_object* v_q_1_, lean_object* v_t_2_){
_start:
{
lean_object* v_fst_3_; 
v_fst_3_ = lean_ctor_get(v_t_2_, 0);
lean_inc(v_fst_3_);
if (lean_obj_tag(v_fst_3_) == 0)
{
lean_object* v_snd_4_; lean_object* v___x_6_; uint8_t v_isShared_7_; uint8_t v_isSharedCheck_23_; 
v_snd_4_ = lean_ctor_get(v_t_2_, 1);
v_isSharedCheck_23_ = !lean_is_exclusive(v_t_2_);
if (v_isSharedCheck_23_ == 0)
{
lean_object* v_unused_24_; 
v_unused_24_ = lean_ctor_get(v_t_2_, 0);
lean_dec(v_unused_24_);
v___x_6_ = v_t_2_;
v_isShared_7_ = v_isSharedCheck_23_;
goto v_resetjp_5_;
}
else
{
lean_inc(v_snd_4_);
lean_dec(v_t_2_);
v___x_6_ = lean_box(0);
v_isShared_7_ = v_isSharedCheck_23_;
goto v_resetjp_5_;
}
v_resetjp_5_:
{
lean_object* v_val_8_; lean_object* v_fst_9_; lean_object* v_snd_10_; lean_object* v___x_12_; uint8_t v_isShared_13_; uint8_t v_isSharedCheck_22_; 
v_val_8_ = lean_ctor_get(v_fst_3_, 0);
lean_inc(v_val_8_);
lean_dec_ref_known(v_fst_3_, 1);
v_fst_9_ = lean_ctor_get(v_snd_4_, 0);
v_snd_10_ = lean_ctor_get(v_snd_4_, 1);
v_isSharedCheck_22_ = !lean_is_exclusive(v_snd_4_);
if (v_isSharedCheck_22_ == 0)
{
v___x_12_ = v_snd_4_;
v_isShared_13_ = v_isSharedCheck_22_;
goto v_resetjp_11_;
}
else
{
lean_inc(v_snd_10_);
lean_inc(v_fst_9_);
lean_dec(v_snd_4_);
v___x_12_ = lean_box(0);
v_isShared_13_ = v_isSharedCheck_22_;
goto v_resetjp_11_;
}
v_resetjp_11_:
{
lean_object* v___x_14_; lean_object* v___x_15_; lean_object* v___x_17_; 
v___x_14_ = lean_nat_add(v_q_1_, v_fst_9_);
lean_dec(v_fst_9_);
v___x_15_ = lean_nat_add(v_q_1_, v_snd_10_);
lean_dec(v_snd_10_);
if (v_isShared_13_ == 0)
{
lean_ctor_set(v___x_12_, 1, v___x_15_);
lean_ctor_set(v___x_12_, 0, v___x_14_);
v___x_17_ = v___x_12_;
goto v_reusejp_16_;
}
else
{
lean_object* v_reuseFailAlloc_21_; 
v_reuseFailAlloc_21_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_21_, 0, v___x_14_);
lean_ctor_set(v_reuseFailAlloc_21_, 1, v___x_15_);
v___x_17_ = v_reuseFailAlloc_21_;
goto v_reusejp_16_;
}
v_reusejp_16_:
{
lean_object* v___x_19_; 
if (v_isShared_7_ == 0)
{
lean_ctor_set(v___x_6_, 1, v___x_17_);
lean_ctor_set(v___x_6_, 0, v_val_8_);
v___x_19_ = v___x_6_;
goto v_reusejp_18_;
}
else
{
lean_object* v_reuseFailAlloc_20_; 
v_reuseFailAlloc_20_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_20_, 0, v_val_8_);
lean_ctor_set(v_reuseFailAlloc_20_, 1, v___x_17_);
v___x_19_ = v_reuseFailAlloc_20_;
goto v_reusejp_18_;
}
v_reusejp_18_:
{
return v___x_19_;
}
}
}
}
}
else
{
lean_object* v_snd_25_; lean_object* v___x_27_; uint8_t v_isShared_28_; uint8_t v_isSharedCheck_42_; 
v_snd_25_ = lean_ctor_get(v_t_2_, 1);
v_isSharedCheck_42_ = !lean_is_exclusive(v_t_2_);
if (v_isSharedCheck_42_ == 0)
{
lean_object* v_unused_43_; 
v_unused_43_ = lean_ctor_get(v_t_2_, 0);
lean_dec(v_unused_43_);
v___x_27_ = v_t_2_;
v_isShared_28_ = v_isSharedCheck_42_;
goto v_resetjp_26_;
}
else
{
lean_inc(v_snd_25_);
lean_dec(v_t_2_);
v___x_27_ = lean_box(0);
v_isShared_28_ = v_isSharedCheck_42_;
goto v_resetjp_26_;
}
v_resetjp_26_:
{
lean_object* v_val_29_; lean_object* v_fst_30_; lean_object* v_snd_31_; lean_object* v___x_33_; uint8_t v_isShared_34_; uint8_t v_isSharedCheck_41_; 
v_val_29_ = lean_ctor_get(v_fst_3_, 0);
lean_inc(v_val_29_);
lean_dec_ref_known(v_fst_3_, 1);
v_fst_30_ = lean_ctor_get(v_snd_25_, 0);
v_snd_31_ = lean_ctor_get(v_snd_25_, 1);
v_isSharedCheck_41_ = !lean_is_exclusive(v_snd_25_);
if (v_isSharedCheck_41_ == 0)
{
v___x_33_ = v_snd_25_;
v_isShared_34_ = v_isSharedCheck_41_;
goto v_resetjp_32_;
}
else
{
lean_inc(v_snd_31_);
lean_inc(v_fst_30_);
lean_dec(v_snd_25_);
v___x_33_ = lean_box(0);
v_isShared_34_ = v_isSharedCheck_41_;
goto v_resetjp_32_;
}
v_resetjp_32_:
{
lean_object* v___x_36_; 
if (v_isShared_34_ == 0)
{
v___x_36_ = v___x_33_;
goto v_reusejp_35_;
}
else
{
lean_object* v_reuseFailAlloc_40_; 
v_reuseFailAlloc_40_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_40_, 0, v_fst_30_);
lean_ctor_set(v_reuseFailAlloc_40_, 1, v_snd_31_);
v___x_36_ = v_reuseFailAlloc_40_;
goto v_reusejp_35_;
}
v_reusejp_35_:
{
lean_object* v___x_38_; 
if (v_isShared_28_ == 0)
{
lean_ctor_set(v___x_27_, 1, v___x_36_);
lean_ctor_set(v___x_27_, 0, v_val_29_);
v___x_38_ = v___x_27_;
goto v_reusejp_37_;
}
else
{
lean_object* v_reuseFailAlloc_39_; 
v_reuseFailAlloc_39_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_39_, 0, v_val_29_);
lean_ctor_set(v_reuseFailAlloc_39_, 1, v___x_36_);
v___x_38_ = v_reuseFailAlloc_39_;
goto v_reusejp_37_;
}
v_reusejp_37_:
{
return v___x_38_;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_GenMat_loc___redArg___boxed(lean_object* v_q_44_, lean_object* v_t_45_){
_start:
{
lean_object* v_res_46_; 
v_res_46_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_GenMat_loc___redArg(v_q_44_, v_t_45_);
lean_dec(v_q_44_);
return v_res_46_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_GenMat_loc(lean_object* v_00_u03a8_47_, lean_object* v_p_48_, lean_object* v_q_49_, lean_object* v_t_50_){
_start:
{
lean_object* v___x_51_; 
v___x_51_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_GenMat_loc___redArg(v_q_49_, v_t_50_);
return v___x_51_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_GenMat_loc___boxed(lean_object* v_00_u03a8_52_, lean_object* v_p_53_, lean_object* v_q_54_, lean_object* v_t_55_){
_start:
{
lean_object* v_res_56_; 
v_res_56_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_GenMat_loc(v_00_u03a8_52_, v_p_53_, v_q_54_, v_t_55_);
lean_dec(v_q_54_);
lean_dec(v_p_53_);
return v_res_56_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_GMatIsGenericFlag(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
