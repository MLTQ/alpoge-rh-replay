// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.MultAtTwistQuadEq
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Proofs.MetricProofs.IsHorizontalTwist public import GroundTheory.HeightsAndTheta.Heights.DiscreteValuationNumbers.PSpecialMultAt public import GroundTheory.HeightsAndTheta.Heights.Intersections.PBCMult public import GroundTheory.HeightsAndTheta.Heights.ArithmeticBezout.LengthLocalizedModuleQuotient
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_MultAtTwistQuadEq_0__GlobalTheory_CompanionTheory_Ar_Tw_toPoly_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_MultAtTwistQuadEq_0__GlobalTheory_CompanionTheory_Ar_Tw_toPoly_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_MultAtTwistQuadEq_0__GlobalTheory_CompanionTheory_Ar_Tw_toPoly_match__1_splitter___redArg(lean_object* v_q_1_, lean_object* v_h__1_2_, lean_object* v_h__2_3_){
_start:
{
lean_object* v_fst_4_; 
v_fst_4_ = lean_ctor_get(v_q_1_, 0);
if (lean_obj_tag(v_fst_4_) == 0)
{
lean_object* v_snd_5_; lean_object* v___x_6_; 
lean_dec(v_h__2_3_);
v_snd_5_ = lean_ctor_get(v_q_1_, 1);
lean_inc(v_snd_5_);
lean_dec_ref(v_q_1_);
v___x_6_ = lean_apply_1(v_h__1_2_, v_snd_5_);
return v___x_6_;
}
else
{
lean_object* v_snd_7_; lean_object* v_val_8_; lean_object* v___x_9_; 
lean_inc_ref(v_fst_4_);
lean_dec(v_h__1_2_);
v_snd_7_ = lean_ctor_get(v_q_1_, 1);
lean_inc(v_snd_7_);
lean_dec_ref(v_q_1_);
v_val_8_ = lean_ctor_get(v_fst_4_, 0);
lean_inc(v_val_8_);
lean_dec_ref_known(v_fst_4_, 1);
v___x_9_ = lean_apply_2(v_h__2_3_, v_val_8_, v_snd_7_);
return v___x_9_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_MultAtTwistQuadEq_0__GlobalTheory_CompanionTheory_Ar_Tw_toPoly_match__1_splitter(lean_object* v_K_10_, lean_object* v_00_u03b9_11_, lean_object* v_motive_12_, lean_object* v_q_13_, lean_object* v_h__1_14_, lean_object* v_h__2_15_){
_start:
{
lean_object* v_fst_16_; 
v_fst_16_ = lean_ctor_get(v_q_13_, 0);
if (lean_obj_tag(v_fst_16_) == 0)
{
lean_object* v_snd_17_; lean_object* v___x_18_; 
lean_dec(v_h__2_15_);
v_snd_17_ = lean_ctor_get(v_q_13_, 1);
lean_inc(v_snd_17_);
lean_dec_ref(v_q_13_);
v___x_18_ = lean_apply_1(v_h__1_14_, v_snd_17_);
return v___x_18_;
}
else
{
lean_object* v_snd_19_; lean_object* v_val_20_; lean_object* v___x_21_; 
lean_inc_ref(v_fst_16_);
lean_dec(v_h__1_14_);
v_snd_19_ = lean_ctor_get(v_q_13_, 1);
lean_inc(v_snd_19_);
lean_dec_ref(v_q_13_);
v_val_20_ = lean_ctor_get(v_fst_16_, 0);
lean_inc(v_val_20_);
lean_dec_ref_known(v_fst_16_, 1);
v___x_21_ = lean_apply_2(v_h__2_15_, v_val_20_, v_snd_19_);
return v___x_21_;
}
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsHorizontalTwist(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_DiscreteValuationNumbers_PSpecialMultAt(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_Intersections_PBCMult(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_ArithmeticBezout_LengthLocalizedModuleQuotient(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_MultAtTwistQuadEq(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsHorizontalTwist(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_DiscreteValuationNumbers_PSpecialMultAt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_Intersections_PBCMult(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_ArithmeticBezout_LengthLocalizedModuleQuotient(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
