// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.HodgeCptFrameLeadingTerm
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Proofs.MetricProofs.ColFlags public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.ExistsProperIntegralModelStatement public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.DominatesOfCoordsRegularStatement public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FunctionFieldRatioGeneratorsStatement public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameMatrixChartRatiosStatement public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FlagFramesGenericModelRightStatement
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_sumPiEquivProdPi(lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_segIxEquiv___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_segIxEquiv___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_segIxEquiv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_segIxEquiv___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_segIxEquiv___closed__0(void){
_start:
{
lean_object* v___x_1_; 
v___x_1_ = lp_mathlib_Equiv_sumPiEquivProdPi(lean_box(0), lean_box(0), lean_box(0));
return v___x_1_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_segIxEquiv(lean_object* v_00_u03a8_2_, lean_object* v_p_3_, lean_object* v_q_4_, lean_object* v_n_5_, lean_object* v_K_u2080_6_, lean_object* v_J_u2080_7_){
_start:
{
lean_object* v___x_8_; 
v___x_8_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_segIxEquiv___closed__0, &lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_segIxEquiv___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_segIxEquiv___closed__0);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_segIxEquiv___boxed(lean_object* v_00_u03a8_9_, lean_object* v_p_10_, lean_object* v_q_11_, lean_object* v_n_12_, lean_object* v_K_u2080_13_, lean_object* v_J_u2080_14_){
_start:
{
lean_object* v_res_15_; 
v_res_15_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_segIxEquiv(v_00_u03a8_9_, v_p_10_, v_q_11_, v_n_12_, v_K_u2080_13_, v_J_u2080_14_);
lean_dec_ref(v_n_12_);
lean_dec(v_q_11_);
lean_dec(v_p_10_);
return v_res_15_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_ExistsProperIntegralModelStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_DominatesOfCoordsRegularStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FunctionFieldRatioGeneratorsStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FrameMatrixChartRatiosStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FlagFramesGenericModelRightStatement(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameLeadingTerm(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_ExistsProperIntegralModelStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_DominatesOfCoordsRegularStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FunctionFieldRatioGeneratorsStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FrameMatrixChartRatiosStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FlagFramesGenericModelRightStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
