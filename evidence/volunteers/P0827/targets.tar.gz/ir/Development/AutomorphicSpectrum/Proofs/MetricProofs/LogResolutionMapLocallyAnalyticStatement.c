// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.LogResolutionMapLocallyAnalyticStatement
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Proofs.MetricProofs.LogResolutionMapLocallyAnalytic public import Development.AutomorphicSpectrum.Definitions.MetricPeriods.Pull1 public import Development.AutomorphicSpectrum.Definitions.MetricPeriods.IsPeriodOn public import Development.AutomorphicSpectrum.Proofs.MetricProofs.IsImg public import GroundTheory.HeightsAndTheta.Heights.Intersections.PtsOverPt
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_LogResolutionMapLocallyAnalytic(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_Pull1(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_IsPeriodOn(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsImg(uint8_t builtin);
lean_object* initialize_tree_GroundTheory_HeightsAndTheta_Heights_Intersections_PtsOverPt(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_LogResolutionMapLocallyAnalyticStatement(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_LogResolutionMapLocallyAnalytic(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_Pull1(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Definitions_MetricPeriods_IsPeriodOn(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_IsImg(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_GroundTheory_HeightsAndTheta_Heights_Intersections_PtsOverPt(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
