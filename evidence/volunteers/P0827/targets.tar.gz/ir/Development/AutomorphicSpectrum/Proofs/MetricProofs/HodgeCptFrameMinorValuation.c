// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.HodgeCptFrameMinorValuation
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Proofs.MetricProofs.ColFlags public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameChangeByUnitMatrix
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_xb___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_CommRing_toCommMonoid___redArg(lean_object*);
lean_object* lp_mathlib_Finset_prod___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_rkW___redArg(lean_object*, lean_object*);
lean_object* lean_nat_mul(lean_object*, lean_object*);
lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_rkO___redArg(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toCommGroupWithZero___redArg(lean_object*);
lean_object* lp_mathlib_CommGroupWithZero_toDivisionCommMonoid___redArg(lean_object*);
lean_object* lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_inlB___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_inlB(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_inlB___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO___redArg___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_c_u2080___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_c_u2080(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_c_u2080___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zW___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zW(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zW___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zO___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zO(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zO___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_wtOf___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_wtOf___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_wtOf(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_wtOf___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_minorIJ__single___aux__1__1___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_minorIJ__single___aux__1__1___closed__0;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_minorIJ__single___aux__1__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_minorIJ__single___aux__1__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_aW___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_aW(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_aW___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_inlB___redArg(lean_object* v_k_u2080_1_){
_start:
{
lean_object* v___x_2_; 
v___x_2_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_2_, 0, v_k_u2080_1_);
return v___x_2_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_inlB(lean_object* v_00_u03a8_3_, lean_object* v_p_4_, lean_object* v_q_5_, lean_object* v_K_u2080_6_, lean_object* v_k_u2080_7_){
_start:
{
lean_object* v___x_8_; 
v___x_8_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_8_, 0, v_k_u2080_7_);
return v___x_8_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_inlB___boxed(lean_object* v_00_u03a8_9_, lean_object* v_p_10_, lean_object* v_q_11_, lean_object* v_K_u2080_12_, lean_object* v_k_u2080_13_){
_start:
{
lean_object* v_res_14_; 
v_res_14_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_inlB(v_00_u03a8_9_, v_p_10_, v_q_11_, v_K_u2080_12_, v_k_u2080_13_);
lean_dec(v_q_11_);
lean_dec(v_p_10_);
return v_res_14_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW___redArg(lean_object* v_p_15_, lean_object* v_00_u03c4_16_){
_start:
{
lean_object* v___x_17_; lean_object* v___x_18_; lean_object* v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; 
v___x_17_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_17_, 0, v_00_u03c4_16_);
v___x_18_ = lean_unsigned_to_nat(1u);
v___x_19_ = lean_nat_sub(v_p_15_, v___x_18_);
v___x_20_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_20_, 0, v___x_17_);
lean_ctor_set(v___x_20_, 1, v___x_19_);
v___x_21_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_21_, 0, v___x_20_);
return v___x_21_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW___redArg___boxed(lean_object* v_p_22_, lean_object* v_00_u03c4_23_){
_start:
{
lean_object* v_res_24_; 
v_res_24_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW___redArg(v_p_22_, v_00_u03c4_23_);
lean_dec(v_p_22_);
return v_res_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW(lean_object* v_00_u03a8_25_, lean_object* v_p_26_, lean_object* v_q_27_, lean_object* v_K_u2080_28_, lean_object* v_00_u03c4_29_, lean_object* v_hp_30_){
_start:
{
lean_object* v___x_31_; 
v___x_31_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW___redArg(v_p_26_, v_00_u03c4_29_);
return v___x_31_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW___boxed(lean_object* v_00_u03a8_32_, lean_object* v_p_33_, lean_object* v_q_34_, lean_object* v_K_u2080_35_, lean_object* v_00_u03c4_36_, lean_object* v_hp_37_){
_start:
{
lean_object* v_res_38_; 
v_res_38_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW(v_00_u03a8_32_, v_p_33_, v_q_34_, v_K_u2080_35_, v_00_u03c4_36_, v_hp_37_);
lean_dec(v_q_34_);
lean_dec(v_p_33_);
return v_res_38_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO___redArg(lean_object* v_q_39_, lean_object* v_00_u03c4_40_){
_start:
{
lean_object* v___x_41_; lean_object* v___x_42_; lean_object* v___x_43_; lean_object* v___x_44_; lean_object* v___x_45_; 
v___x_41_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_41_, 0, v_00_u03c4_40_);
v___x_42_ = lean_unsigned_to_nat(1u);
v___x_43_ = lean_nat_sub(v_q_39_, v___x_42_);
v___x_44_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_44_, 0, v___x_41_);
lean_ctor_set(v___x_44_, 1, v___x_43_);
v___x_45_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_45_, 0, v___x_44_);
return v___x_45_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO___redArg___boxed(lean_object* v_q_46_, lean_object* v_00_u03c4_47_){
_start:
{
lean_object* v_res_48_; 
v_res_48_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO___redArg(v_q_46_, v_00_u03c4_47_);
lean_dec(v_q_46_);
return v_res_48_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO(lean_object* v_00_u03a8_49_, lean_object* v_p_50_, lean_object* v_q_51_, lean_object* v_K_u2080_52_, lean_object* v_00_u03c4_53_, lean_object* v_hq_54_){
_start:
{
lean_object* v___x_55_; 
v___x_55_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO___redArg(v_q_51_, v_00_u03c4_53_);
return v___x_55_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO___boxed(lean_object* v_00_u03a8_56_, lean_object* v_p_57_, lean_object* v_q_58_, lean_object* v_K_u2080_59_, lean_object* v_00_u03c4_60_, lean_object* v_hq_61_){
_start:
{
lean_object* v_res_62_; 
v_res_62_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO(v_00_u03a8_56_, v_p_57_, v_q_58_, v_K_u2080_59_, v_00_u03c4_60_, v_hq_61_);
lean_dec(v_q_58_);
lean_dec(v_p_57_);
return v_res_62_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_c_u2080___redArg(lean_object* v_F_63_, lean_object* v_k_u2080_64_){
_start:
{
lean_object* v_c_65_; lean_object* v___x_66_; lean_object* v___x_67_; 
v_c_65_ = lean_ctor_get(v_F_63_, 0);
lean_inc(v_c_65_);
lean_dec_ref(v_F_63_);
v___x_66_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_66_, 0, v_k_u2080_64_);
v___x_67_ = lean_apply_1(v_c_65_, v___x_66_);
return v___x_67_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_c_u2080(lean_object* v_00_u03a8_68_, lean_object* v_p_69_, lean_object* v_q_70_, lean_object* v_00_u03a9_71_, lean_object* v_inst_72_, lean_object* v_n_73_, lean_object* v_K_u2080_74_, lean_object* v_J_u2080_75_, lean_object* v_F_76_, lean_object* v_k_u2080_77_){
_start:
{
lean_object* v___x_78_; 
v___x_78_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_c_u2080___redArg(v_F_76_, v_k_u2080_77_);
return v___x_78_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_c_u2080___boxed(lean_object* v_00_u03a8_79_, lean_object* v_p_80_, lean_object* v_q_81_, lean_object* v_00_u03a9_82_, lean_object* v_inst_83_, lean_object* v_n_84_, lean_object* v_K_u2080_85_, lean_object* v_J_u2080_86_, lean_object* v_F_87_, lean_object* v_k_u2080_88_){
_start:
{
lean_object* v_res_89_; 
v_res_89_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_c_u2080(v_00_u03a8_79_, v_p_80_, v_q_81_, v_00_u03a9_82_, v_inst_83_, v_n_84_, v_K_u2080_85_, v_J_u2080_86_, v_F_87_, v_k_u2080_88_);
lean_dec_ref(v_n_84_);
lean_dec_ref(v_inst_83_);
lean_dec(v_q_81_);
lean_dec(v_p_80_);
return v_res_89_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX___redArg___lam__0(lean_object* v_F_90_, lean_object* v_x_u2080_91_, lean_object* v_k_u2080_92_){
_start:
{
lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; 
lean_inc(v_k_u2080_92_);
v___x_93_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_c_u2080___redArg(v_F_90_, v_k_u2080_92_);
v___x_94_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_94_, 0, v_k_u2080_92_);
lean_ctor_set(v___x_94_, 1, v___x_93_);
v___x_95_ = lean_apply_1(v_x_u2080_91_, v___x_94_);
return v___x_95_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX___redArg(lean_object* v_inst_96_, lean_object* v_inst_97_, lean_object* v_x_u2080_98_, lean_object* v_F_99_){
_start:
{
lean_object* v_toCommRing_100_; lean_object* v___f_101_; lean_object* v___x_102_; lean_object* v___x_103_; 
v_toCommRing_100_ = lean_ctor_get(v_inst_96_, 0);
v___f_101_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX___redArg___lam__0), 3, 2);
lean_closure_set(v___f_101_, 0, v_F_99_);
lean_closure_set(v___f_101_, 1, v_x_u2080_98_);
v___x_102_ = lp_mathlib_CommRing_toCommMonoid___redArg(v_toCommRing_100_);
v___x_103_ = lp_mathlib_Finset_prod___redArg(v___x_102_, v_inst_97_, v___f_101_);
lean_dec_ref(v___x_102_);
return v___x_103_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX___redArg___boxed(lean_object* v_inst_104_, lean_object* v_inst_105_, lean_object* v_x_u2080_106_, lean_object* v_F_107_){
_start:
{
lean_object* v_res_108_; 
v_res_108_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX___redArg(v_inst_104_, v_inst_105_, v_x_u2080_106_, v_F_107_);
lean_dec_ref(v_inst_104_);
return v_res_108_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX(lean_object* v_00_u03a8_109_, lean_object* v_p_110_, lean_object* v_q_111_, lean_object* v_00_u03a9_112_, lean_object* v_inst_113_, lean_object* v_n_114_, lean_object* v_K_u2080_115_, lean_object* v_inst_116_, lean_object* v_J_u2080_117_, lean_object* v_x_u2080_118_, lean_object* v_F_119_){
_start:
{
lean_object* v___x_120_; 
v___x_120_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX___redArg(v_inst_113_, v_inst_116_, v_x_u2080_118_, v_F_119_);
return v___x_120_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX___boxed(lean_object* v_00_u03a8_121_, lean_object* v_p_122_, lean_object* v_q_123_, lean_object* v_00_u03a9_124_, lean_object* v_inst_125_, lean_object* v_n_126_, lean_object* v_K_u2080_127_, lean_object* v_inst_128_, lean_object* v_J_u2080_129_, lean_object* v_x_u2080_130_, lean_object* v_F_131_){
_start:
{
lean_object* v_res_132_; 
v_res_132_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_chartX(v_00_u03a8_121_, v_p_122_, v_q_123_, v_00_u03a9_124_, v_inst_125_, v_n_126_, v_K_u2080_127_, v_inst_128_, v_J_u2080_129_, v_x_u2080_130_, v_F_131_);
lean_dec_ref(v_n_126_);
lean_dec_ref(v_inst_125_);
lean_dec(v_q_123_);
lean_dec(v_p_122_);
return v_res_132_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zW___redArg(lean_object* v_p_133_, lean_object* v_q_134_, lean_object* v_inst_135_, lean_object* v_A_136_, lean_object* v_x_u2080_137_, lean_object* v_F_138_, lean_object* v_00_u03c4_139_){
_start:
{
lean_object* v_c_140_; lean_object* v___x_141_; lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; 
v_c_140_ = lean_ctor_get(v_F_138_, 0);
lean_inc(v_c_140_);
lean_dec_ref(v_F_138_);
v___x_141_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullW___redArg(v_p_133_, v_00_u03c4_139_);
lean_inc_ref(v___x_141_);
v___x_142_ = lean_apply_1(v_c_140_, v___x_141_);
v___x_143_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_143_, 0, v___x_141_);
lean_ctor_set(v___x_143_, 1, v___x_142_);
v___x_144_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_xb___redArg(v_p_133_, v_q_134_, v_inst_135_, v_A_136_, v_x_u2080_137_, v___x_143_);
return v___x_144_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zW(lean_object* v_00_u03a8_145_, lean_object* v_p_146_, lean_object* v_q_147_, lean_object* v_00_u03a9_148_, lean_object* v_inst_149_, lean_object* v_n_150_, lean_object* v_A_151_, lean_object* v_K_u2080_152_, lean_object* v_J_u2080_153_, lean_object* v_x_u2080_154_, lean_object* v_F_155_, lean_object* v_00_u03c4_156_, lean_object* v_hp_157_){
_start:
{
lean_object* v___x_158_; 
v___x_158_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zW___redArg(v_p_146_, v_q_147_, v_inst_149_, v_A_151_, v_x_u2080_154_, v_F_155_, v_00_u03c4_156_);
return v___x_158_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zW___boxed(lean_object* v_00_u03a8_159_, lean_object* v_p_160_, lean_object* v_q_161_, lean_object* v_00_u03a9_162_, lean_object* v_inst_163_, lean_object* v_n_164_, lean_object* v_A_165_, lean_object* v_K_u2080_166_, lean_object* v_J_u2080_167_, lean_object* v_x_u2080_168_, lean_object* v_F_169_, lean_object* v_00_u03c4_170_, lean_object* v_hp_171_){
_start:
{
lean_object* v_res_172_; 
v_res_172_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zW(v_00_u03a8_159_, v_p_160_, v_q_161_, v_00_u03a9_162_, v_inst_163_, v_n_164_, v_A_165_, v_K_u2080_166_, v_J_u2080_167_, v_x_u2080_168_, v_F_169_, v_00_u03c4_170_, v_hp_171_);
lean_dec_ref(v_n_164_);
return v_res_172_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zO___redArg(lean_object* v_p_173_, lean_object* v_q_174_, lean_object* v_inst_175_, lean_object* v_A_176_, lean_object* v_x_u2080_177_, lean_object* v_F_178_, lean_object* v_00_u03c4_179_){
_start:
{
lean_object* v_c_180_; lean_object* v___x_181_; lean_object* v___x_182_; lean_object* v___x_183_; lean_object* v___x_184_; 
v_c_180_ = lean_ctor_get(v_F_178_, 0);
lean_inc(v_c_180_);
lean_dec_ref(v_F_178_);
v___x_181_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_fullO___redArg(v_q_174_, v_00_u03c4_179_);
lean_inc_ref(v___x_181_);
v___x_182_ = lean_apply_1(v_c_180_, v___x_181_);
v___x_183_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_183_, 0, v___x_181_);
lean_ctor_set(v___x_183_, 1, v___x_182_);
v___x_184_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_xb___redArg(v_p_173_, v_q_174_, v_inst_175_, v_A_176_, v_x_u2080_177_, v___x_183_);
return v___x_184_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zO(lean_object* v_00_u03a8_185_, lean_object* v_p_186_, lean_object* v_q_187_, lean_object* v_00_u03a9_188_, lean_object* v_inst_189_, lean_object* v_n_190_, lean_object* v_A_191_, lean_object* v_K_u2080_192_, lean_object* v_J_u2080_193_, lean_object* v_x_u2080_194_, lean_object* v_F_195_, lean_object* v_00_u03c4_196_, lean_object* v_hq_197_){
_start:
{
lean_object* v___x_198_; 
v___x_198_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zO___redArg(v_p_186_, v_q_187_, v_inst_189_, v_A_191_, v_x_u2080_194_, v_F_195_, v_00_u03c4_196_);
return v___x_198_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zO___boxed(lean_object* v_00_u03a8_199_, lean_object* v_p_200_, lean_object* v_q_201_, lean_object* v_00_u03a9_202_, lean_object* v_inst_203_, lean_object* v_n_204_, lean_object* v_A_205_, lean_object* v_K_u2080_206_, lean_object* v_J_u2080_207_, lean_object* v_x_u2080_208_, lean_object* v_F_209_, lean_object* v_00_u03c4_210_, lean_object* v_hq_211_){
_start:
{
lean_object* v_res_212_; 
v_res_212_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zO(v_00_u03a8_199_, v_p_200_, v_q_201_, v_00_u03a9_202_, v_inst_203_, v_n_204_, v_A_205_, v_K_u2080_206_, v_J_u2080_207_, v_x_u2080_208_, v_F_209_, v_00_u03c4_210_, v_hq_211_);
lean_dec_ref(v_n_204_);
return v_res_212_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_wtOf___redArg(lean_object* v_p_213_, lean_object* v_m_214_, lean_object* v_r_215_){
_start:
{
lean_object* v_fst_216_; lean_object* v_snd_217_; lean_object* v___x_218_; lean_object* v___x_219_; lean_object* v___x_220_; lean_object* v___x_221_; lean_object* v___x_222_; lean_object* v___x_223_; lean_object* v___x_224_; lean_object* v___x_225_; lean_object* v___x_226_; 
v_fst_216_ = lean_ctor_get(v_r_215_, 0);
v_snd_217_ = lean_ctor_get(v_r_215_, 1);
v___x_218_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_rkW___redArg(v_p_213_, v_snd_217_);
lean_inc_n(v_fst_216_, 2);
v___x_219_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_219_, 0, v_fst_216_);
lean_inc_ref(v_m_214_);
v___x_220_ = lean_apply_1(v_m_214_, v___x_219_);
v___x_221_ = lean_nat_mul(v___x_218_, v___x_220_);
lean_dec(v___x_220_);
lean_dec(v___x_218_);
v___x_222_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_rkO___redArg(v_p_213_, v_snd_217_);
v___x_223_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_223_, 0, v_fst_216_);
v___x_224_ = lean_apply_1(v_m_214_, v___x_223_);
v___x_225_ = lean_nat_mul(v___x_222_, v___x_224_);
lean_dec(v___x_224_);
lean_dec(v___x_222_);
v___x_226_ = lean_nat_add(v___x_221_, v___x_225_);
lean_dec(v___x_225_);
lean_dec(v___x_221_);
return v___x_226_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_wtOf___redArg___boxed(lean_object* v_p_227_, lean_object* v_m_228_, lean_object* v_r_229_){
_start:
{
lean_object* v_res_230_; 
v_res_230_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_wtOf___redArg(v_p_227_, v_m_228_, v_r_229_);
lean_dec_ref(v_r_229_);
lean_dec(v_p_227_);
return v_res_230_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_wtOf(lean_object* v_00_u03a8_231_, lean_object* v_p_232_, lean_object* v_q_233_, lean_object* v_m_234_, lean_object* v_r_235_){
_start:
{
lean_object* v___x_236_; 
v___x_236_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_wtOf___redArg(v_p_232_, v_m_234_, v_r_235_);
return v___x_236_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_wtOf___boxed(lean_object* v_00_u03a8_237_, lean_object* v_p_238_, lean_object* v_q_239_, lean_object* v_m_240_, lean_object* v_r_241_){
_start:
{
lean_object* v_res_242_; 
v_res_242_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_wtOf(v_00_u03a8_237_, v_p_238_, v_q_239_, v_m_240_, v_r_241_);
lean_dec_ref(v_r_241_);
lean_dec(v_q_239_);
lean_dec(v_p_238_);
return v_res_242_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_minorIJ__single___aux__1__1___closed__0(void){
_start:
{
lean_object* v___x_243_; lean_object* v___x_244_; lean_object* v___x_245_; 
v___x_243_ = lean_unsigned_to_nat(1u);
v___x_244_ = lean_unsigned_to_nat(0u);
v___x_245_ = lean_nat_mod(v___x_244_, v___x_243_);
return v___x_245_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_minorIJ__single___aux__1__1(lean_object* v_N_246_, lean_object* v_b_247_){
_start:
{
lean_object* v___x_248_; 
v___x_248_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_minorIJ__single___aux__1__1___closed__0, &lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_minorIJ__single___aux__1__1___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_minorIJ__single___aux__1__1___closed__0);
return v___x_248_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_minorIJ__single___aux__1__1___boxed(lean_object* v_N_249_, lean_object* v_b_250_){
_start:
{
lean_object* v_res_251_; 
v_res_251_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_minorIJ__single___aux__1__1(v_N_249_, v_b_250_);
lean_dec(v_b_250_);
lean_dec(v_N_249_);
return v_res_251_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_aW___redArg(lean_object* v_p_252_, lean_object* v_q_253_, lean_object* v_inst_254_, lean_object* v_A_255_, lean_object* v_x_u2080_256_, lean_object* v_F_257_, lean_object* v_00_u03c4_258_){
_start:
{
lean_object* v___x_259_; uint8_t v___x_260_; 
v___x_259_ = lean_unsigned_to_nat(0u);
v___x_260_ = lean_nat_dec_lt(v___x_259_, v_p_252_);
if (v___x_260_ == 0)
{
lean_object* v___x_261_; lean_object* v_toRing_262_; lean_object* v___x_263_; lean_object* v_toAddMonoidWithOne_264_; lean_object* v_toOne_265_; 
lean_dec(v_00_u03c4_258_);
lean_dec_ref(v_F_257_);
lean_dec(v_x_u2080_256_);
lean_dec(v_A_255_);
lean_dec(v_q_253_);
lean_dec(v_p_252_);
v___x_261_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_254_);
v_toRing_262_ = lean_ctor_get(v___x_261_, 0);
lean_inc_ref(v_toRing_262_);
lean_dec_ref(v___x_261_);
v___x_263_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_262_);
v_toAddMonoidWithOne_264_ = lean_ctor_get(v___x_263_, 1);
lean_inc_ref(v_toAddMonoidWithOne_264_);
lean_dec_ref(v___x_263_);
v_toOne_265_ = lean_ctor_get(v_toAddMonoidWithOne_264_, 2);
lean_inc(v_toOne_265_);
lean_dec_ref(v_toAddMonoidWithOne_264_);
return v_toOne_265_;
}
else
{
lean_object* v___x_266_; lean_object* v___x_267_; lean_object* v___x_268_; lean_object* v___x_269_; lean_object* v_toInv_270_; lean_object* v___x_271_; lean_object* v___x_272_; 
v___x_266_ = lp_mathlib_Field_toSemifield___redArg(v_inst_254_);
v___x_267_ = lp_mathlib_Semifield_toCommGroupWithZero___redArg(v___x_266_);
lean_dec_ref(v___x_266_);
v___x_268_ = lp_mathlib_CommGroupWithZero_toDivisionCommMonoid___redArg(v___x_267_);
v___x_269_ = lp_mathlib_DivInvOneMonoid_toInvOneClass___redArg(v___x_268_);
lean_dec_ref(v___x_268_);
v_toInv_270_ = lean_ctor_get(v___x_269_, 1);
lean_inc(v_toInv_270_);
lean_dec_ref(v___x_269_);
v___x_271_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_zW___redArg(v_p_252_, v_q_253_, v_inst_254_, v_A_255_, v_x_u2080_256_, v_F_257_, v_00_u03c4_258_);
v___x_272_ = lean_apply_1(v_toInv_270_, v___x_271_);
return v___x_272_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_aW(lean_object* v_00_u03a8_273_, lean_object* v_p_274_, lean_object* v_q_275_, lean_object* v_00_u03a9_276_, lean_object* v_inst_277_, lean_object* v_n_278_, lean_object* v_A_279_, lean_object* v_K_u2080_280_, lean_object* v_J_u2080_281_, lean_object* v_x_u2080_282_, lean_object* v_F_283_, lean_object* v_00_u03c4_284_){
_start:
{
lean_object* v___x_285_; 
v___x_285_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_aW___redArg(v_p_274_, v_q_275_, v_inst_277_, v_A_279_, v_x_u2080_282_, v_F_283_, v_00_u03c4_284_);
return v___x_285_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_aW___boxed(lean_object* v_00_u03a8_286_, lean_object* v_p_287_, lean_object* v_q_288_, lean_object* v_00_u03a9_289_, lean_object* v_inst_290_, lean_object* v_n_291_, lean_object* v_A_292_, lean_object* v_K_u2080_293_, lean_object* v_J_u2080_294_, lean_object* v_x_u2080_295_, lean_object* v_F_296_, lean_object* v_00_u03c4_297_){
_start:
{
lean_object* v_res_298_; 
v_res_298_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_FrameAt_aW(v_00_u03a8_286_, v_p_287_, v_q_288_, v_00_u03a9_289_, v_inst_290_, v_n_291_, v_A_292_, v_K_u2080_293_, v_J_u2080_294_, v_x_u2080_295_, v_F_296_, v_00_u03c4_297_);
lean_dec_ref(v_n_291_);
return v_res_298_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FrameChangeByUnitMatrix(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameMinorValuation(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FrameChangeByUnitMatrix(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
