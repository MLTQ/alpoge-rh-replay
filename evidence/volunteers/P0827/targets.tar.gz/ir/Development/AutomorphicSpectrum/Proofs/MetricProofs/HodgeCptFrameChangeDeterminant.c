// Lean compiler output
// Module: Development.AutomorphicSpectrum.Proofs.MetricProofs.HodgeCptFrameChangeDeterminant
// Imports: public import Init public meta import Init public import Mathlib public import Development.AutomorphicSpectrum.Proofs.MetricProofs.ColFlags public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.FrameCoeffsRegularInChart public import Development.AutomorphicSpectrum.Proofs.GeometryProofs.CoordsJoinBlocksStatement public import Development.AutomorphicArithmetic.IntegralCasts.CapelliIdentities.DetT
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_Equiv_refl(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* l_Sum_elim___redArg(lean_object*, lean_object*, lean_object*);
lean_object* l_Fin_castLE___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_submatrix(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_detRowAlternating___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameChangeDeterminant_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameChangeDeterminant_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameChangeDeterminant_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__1___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__0;
static lean_once_cell_t lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__1;
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun___redArg(lean_object* v_x_1_){
_start:
{
if (lean_obj_tag(v_x_1_) == 0)
{
lean_object* v_val_2_; lean_object* v___x_4_; uint8_t v_isShared_5_; uint8_t v_isSharedCheck_9_; 
v_val_2_ = lean_ctor_get(v_x_1_, 0);
v_isSharedCheck_9_ = !lean_is_exclusive(v_x_1_);
if (v_isSharedCheck_9_ == 0)
{
v___x_4_ = v_x_1_;
v_isShared_5_ = v_isSharedCheck_9_;
goto v_resetjp_3_;
}
else
{
lean_inc(v_val_2_);
lean_dec(v_x_1_);
v___x_4_ = lean_box(0);
v_isShared_5_ = v_isSharedCheck_9_;
goto v_resetjp_3_;
}
v_resetjp_3_:
{
lean_object* v___x_7_; 
if (v_isShared_5_ == 0)
{
v___x_7_ = v___x_4_;
goto v_reusejp_6_;
}
else
{
lean_object* v_reuseFailAlloc_8_; 
v_reuseFailAlloc_8_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_8_, 0, v_val_2_);
v___x_7_ = v_reuseFailAlloc_8_;
goto v_reusejp_6_;
}
v_reusejp_6_:
{
return v___x_7_;
}
}
}
else
{
lean_object* v_val_10_; lean_object* v___x_12_; uint8_t v_isShared_13_; uint8_t v_isSharedCheck_17_; 
v_val_10_ = lean_ctor_get(v_x_1_, 0);
v_isSharedCheck_17_ = !lean_is_exclusive(v_x_1_);
if (v_isSharedCheck_17_ == 0)
{
v___x_12_ = v_x_1_;
v_isShared_13_ = v_isSharedCheck_17_;
goto v_resetjp_11_;
}
else
{
lean_inc(v_val_10_);
lean_dec(v_x_1_);
v___x_12_ = lean_box(0);
v_isShared_13_ = v_isSharedCheck_17_;
goto v_resetjp_11_;
}
v_resetjp_11_:
{
lean_object* v___x_15_; 
if (v_isShared_13_ == 0)
{
v___x_15_ = v___x_12_;
goto v_reusejp_14_;
}
else
{
lean_object* v_reuseFailAlloc_16_; 
v_reuseFailAlloc_16_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_16_, 0, v_val_10_);
v___x_15_ = v_reuseFailAlloc_16_;
goto v_reusejp_14_;
}
v_reusejp_14_:
{
return v___x_15_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun(lean_object* v_00_u03a8_18_, lean_object* v_inst_19_, lean_object* v_p_20_, lean_object* v_q_21_, lean_object* v_K_u2080_22_, lean_object* v_x_23_){
_start:
{
lean_object* v___x_24_; 
v___x_24_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun___redArg(v_x_23_);
return v___x_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun___boxed(lean_object* v_00_u03a8_25_, lean_object* v_inst_26_, lean_object* v_p_27_, lean_object* v_q_28_, lean_object* v_K_u2080_29_, lean_object* v_x_30_){
_start:
{
lean_object* v_res_31_; 
v_res_31_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun(v_00_u03a8_25_, v_inst_26_, v_p_27_, v_q_28_, v_K_u2080_29_, v_x_30_);
lean_dec(v_q_28_);
lean_dec(v_p_27_);
lean_dec(v_inst_26_);
return v_res_31_;
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameChangeDeterminant_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun_match__1_splitter___redArg(lean_object* v_x_32_, lean_object* v_h__1_33_, lean_object* v_h__2_34_){
_start:
{
if (lean_obj_tag(v_x_32_) == 0)
{
lean_object* v_val_35_; lean_object* v___x_36_; 
lean_dec(v_h__2_34_);
v_val_35_ = lean_ctor_get(v_x_32_, 0);
lean_inc(v_val_35_);
lean_dec_ref_known(v_x_32_, 1);
v___x_36_ = lean_apply_1(v_h__1_33_, v_val_35_);
return v___x_36_;
}
else
{
lean_object* v_val_37_; lean_object* v___x_38_; 
lean_dec(v_h__1_33_);
v_val_37_ = lean_ctor_get(v_x_32_, 0);
lean_inc(v_val_37_);
lean_dec_ref_known(v_x_32_, 1);
v___x_38_ = lean_apply_1(v_h__2_34_, v_val_37_);
return v___x_38_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameChangeDeterminant_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun_match__1_splitter(lean_object* v_00_u03a8_39_, lean_object* v_p_40_, lean_object* v_q_41_, lean_object* v_K_u2080_42_, lean_object* v_motive_43_, lean_object* v_x_44_, lean_object* v_h__1_45_, lean_object* v_h__2_46_){
_start:
{
if (lean_obj_tag(v_x_44_) == 0)
{
lean_object* v_val_47_; lean_object* v___x_48_; 
lean_dec(v_h__2_46_);
v_val_47_ = lean_ctor_get(v_x_44_, 0);
lean_inc(v_val_47_);
lean_dec_ref_known(v_x_44_, 1);
v___x_48_ = lean_apply_1(v_h__1_45_, v_val_47_);
return v___x_48_;
}
else
{
lean_object* v_val_49_; lean_object* v___x_50_; 
lean_dec(v_h__1_45_);
v_val_49_ = lean_ctor_get(v_x_44_, 0);
lean_inc(v_val_49_);
lean_dec_ref_known(v_x_44_, 1);
v___x_50_ = lean_apply_1(v_h__2_46_, v_val_49_);
return v___x_50_;
}
}
}
LEAN_EXPORT lean_object* lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameChangeDeterminant_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun_match__1_splitter___boxed(lean_object* v_00_u03a8_51_, lean_object* v_p_52_, lean_object* v_q_53_, lean_object* v_K_u2080_54_, lean_object* v_motive_55_, lean_object* v_x_56_, lean_object* v_h__1_57_, lean_object* v_h__2_58_){
_start:
{
lean_object* v_res_59_; 
v_res_59_ = lp_tree___private_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameChangeDeterminant_0__GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseFun_match__1_splitter(v_00_u03a8_51_, v_p_52_, v_q_53_, v_K_u2080_54_, v_motive_55_, v_x_56_, v_h__1_57_, v_h__2_58_);
lean_dec(v_q_53_);
lean_dec(v_p_52_);
return v_res_59_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__0(lean_object* v_p_60_, lean_object* v_x_61_){
_start:
{
lean_inc(v_p_60_);
return v_p_60_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__0___boxed(lean_object* v_p_62_, lean_object* v_x_63_){
_start:
{
lean_object* v_res_64_; 
v_res_64_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__0(v_p_62_, v_x_63_);
lean_dec(v_x_63_);
lean_dec(v_p_62_);
return v_res_64_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__1(lean_object* v_q_65_, lean_object* v_x_66_){
_start:
{
lean_inc(v_q_65_);
return v_q_65_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__1___boxed(lean_object* v_q_67_, lean_object* v_x_68_){
_start:
{
lean_object* v_res_69_; 
v_res_69_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__1(v_q_67_, v_x_68_);
lean_dec(v_x_68_);
lean_dec(v_q_67_);
return v_res_69_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg(lean_object* v_p_70_, lean_object* v_q_71_, lean_object* v_inst_72_, lean_object* v_A_73_, lean_object* v_r_74_){
_start:
{
lean_object* v_fst_75_; lean_object* v_snd_76_; lean_object* v_fst_77_; lean_object* v_snd_78_; lean_object* v_toCommRing_79_; lean_object* v___x_80_; lean_object* v___x_81_; lean_object* v___x_82_; lean_object* v___f_83_; lean_object* v___f_84_; lean_object* v___x_85_; lean_object* v___x_86_; lean_object* v___x_87_; lean_object* v___x_88_; lean_object* v___x_89_; lean_object* v___x_41__overap_90_; lean_object* v___x_91_; 
v_fst_75_ = lean_ctor_get(v_r_74_, 0);
lean_inc(v_fst_75_);
v_snd_76_ = lean_ctor_get(v_r_74_, 1);
lean_inc(v_snd_76_);
lean_dec_ref(v_r_74_);
v_fst_77_ = lean_ctor_get(v_fst_75_, 0);
lean_inc_n(v_fst_77_, 2);
v_snd_78_ = lean_ctor_get(v_fst_75_, 1);
lean_inc(v_snd_78_);
lean_dec(v_fst_75_);
v_toCommRing_79_ = lean_ctor_get(v_inst_72_, 0);
lean_inc_ref(v_toCommRing_79_);
lean_dec_ref(v_inst_72_);
v___x_80_ = lean_unsigned_to_nat(1u);
v___x_81_ = lean_nat_add(v_snd_78_, v___x_80_);
lean_dec(v_snd_78_);
lean_inc_n(v___x_81_, 2);
v___x_82_ = lean_alloc_closure((void*)(l_instDecidableEqFin___boxed), 3, 1);
lean_closure_set(v___x_82_, 0, v___x_81_);
v___f_83_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_83_, 0, v_p_70_);
v___f_84_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg___lam__1___boxed), 2, 1);
lean_closure_set(v___f_84_, 0, v_q_71_);
v___x_85_ = l_List_finRange(v___x_81_);
v___x_86_ = lean_apply_1(v_A_73_, v_fst_77_);
v___x_87_ = l_Sum_elim___redArg(v___f_83_, v___f_84_, v_fst_77_);
v___x_88_ = lean_alloc_closure((void*)(l_Fin_castLE___boxed), 4, 3);
lean_closure_set(v___x_88_, 0, v___x_81_);
lean_closure_set(v___x_88_, 1, v___x_87_);
lean_closure_set(v___x_88_, 2, lean_box(0));
v___x_89_ = lean_alloc_closure((void*)(lp_mathlib_Matrix_submatrix), 10, 8);
lean_closure_set(v___x_89_, 0, lean_box(0));
lean_closure_set(v___x_89_, 1, lean_box(0));
lean_closure_set(v___x_89_, 2, lean_box(0));
lean_closure_set(v___x_89_, 3, lean_box(0));
lean_closure_set(v___x_89_, 4, lean_box(0));
lean_closure_set(v___x_89_, 5, v___x_86_);
lean_closure_set(v___x_89_, 6, v_snd_76_);
lean_closure_set(v___x_89_, 7, v___x_88_);
v___x_41__overap_90_ = lp_mathlib_Matrix_detRowAlternating___redArg(v___x_82_, v___x_85_, v_toCommRing_79_);
v___x_91_ = lean_apply_1(v___x_41__overap_90_, v___x_89_);
return v___x_91_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor(lean_object* v_00_u03a8_92_, lean_object* v_p_93_, lean_object* v_q_94_, lean_object* v_00_u03a9_95_, lean_object* v_inst_96_, lean_object* v_n_97_, lean_object* v_A_98_, lean_object* v_r_99_){
_start:
{
lean_object* v___x_100_; 
v___x_100_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___redArg(v_p_93_, v_q_94_, v_inst_96_, v_A_98_, v_r_99_);
return v___x_100_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor___boxed(lean_object* v_00_u03a8_101_, lean_object* v_p_102_, lean_object* v_q_103_, lean_object* v_00_u03a9_104_, lean_object* v_inst_105_, lean_object* v_n_106_, lean_object* v_A_107_, lean_object* v_r_108_){
_start:
{
lean_object* v_res_109_; 
v_res_109_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_fullMinor(v_00_u03a8_101_, v_p_102_, v_q_103_, v_00_u03a9_104_, v_inst_105_, v_n_106_, v_A_107_, v_r_108_);
lean_dec_ref(v_n_106_);
return v_res_109_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__0(void){
_start:
{
lean_object* v___x_110_; 
v___x_110_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_110_;
}
}
static lean_object* _init_lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__1(void){
_start:
{
lean_object* v___x_111_; 
v___x_111_ = lp_mathlib_Equiv_refl(lean_box(0));
return v___x_111_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg(lean_object* v_x_112_){
_start:
{
if (lean_obj_tag(v_x_112_) == 0)
{
lean_object* v___x_113_; 
v___x_113_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__0, &lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__0_once, _init_lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__0);
return v___x_113_;
}
else
{
lean_object* v___x_114_; 
v___x_114_ = lean_obj_once(&lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__1, &lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__1_once, _init_lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___closed__1);
return v___x_114_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg___boxed(lean_object* v_x_115_){
_start:
{
lean_object* v_res_116_; 
v_res_116_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg(v_x_115_);
lean_dec_ref(v_x_115_);
return v_res_116_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv(lean_object* v_00_u03a8_117_, lean_object* v_inst_118_, lean_object* v_p_119_, lean_object* v_q_120_, lean_object* v_K_u2080_121_, lean_object* v_J_u2080_122_, lean_object* v_n_123_, lean_object* v_x_124_){
_start:
{
lean_object* v___x_125_; 
v___x_125_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___redArg(v_x_124_);
return v___x_125_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv___boxed(lean_object* v_00_u03a8_126_, lean_object* v_inst_127_, lean_object* v_p_128_, lean_object* v_q_129_, lean_object* v_K_u2080_130_, lean_object* v_J_u2080_131_, lean_object* v_n_132_, lean_object* v_x_133_){
_start:
{
lean_object* v_res_134_; 
v_res_134_ = lp_tree_GlobalTheory_CompanionTheory_Ar_PB_FMX_Graph_baseIxEquiv(v_00_u03a8_126_, v_inst_127_, v_p_128_, v_q_129_, v_K_u2080_130_, v_J_u2080_131_, v_n_132_, v_x_133_);
lean_dec_ref(v_x_133_);
lean_dec_ref(v_n_132_);
lean_dec(v_q_129_);
lean_dec(v_p_128_);
lean_dec(v_inst_127_);
return v_res_134_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FrameCoeffsRegularInChart(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_CoordsJoinBlocksStatement(uint8_t builtin);
lean_object* initialize_tree_Development_AutomorphicArithmetic_IntegralCasts_CapelliIdentities_DetT(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_HodgeCptFrameChangeDeterminant(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_MetricProofs_ColFlags(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_FrameCoeffsRegularInChart(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicSpectrum_Proofs_GeometryProofs_CoordsJoinBlocksStatement(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AutomorphicArithmetic_IntegralCasts_CapelliIdentities_DetT(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
