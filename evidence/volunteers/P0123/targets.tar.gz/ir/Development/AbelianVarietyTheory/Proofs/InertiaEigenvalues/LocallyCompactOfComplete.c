// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.LocallyCompactOfComplete
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.UnitLemmaGroup public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.FourierMatch
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Bridge_fixedField(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Bridge_fixedField___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Bridge_fixedField(lean_object* v_E_1_, lean_object* v_inst_2_, lean_object* v_c_3_){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_box(0);
return v___x_4_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Bridge_fixedField___boxed(lean_object* v_E_5_, lean_object* v_inst_6_, lean_object* v_c_7_){
_start:
{
lean_object* v_res_8_; 
v_res_8_ = lp_tree_GlobalTheory_UnitLemma_Bridge_fixedField(v_E_5_, v_inst_6_, v_c_7_);
lean_dec_ref(v_c_7_);
lean_dec_ref(v_inst_6_);
return v_res_8_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_UnitLemmaGroup(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_FourierMatch(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_LocallyCompactOfComplete(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_UnitLemmaGroup(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_FourierMatch(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
