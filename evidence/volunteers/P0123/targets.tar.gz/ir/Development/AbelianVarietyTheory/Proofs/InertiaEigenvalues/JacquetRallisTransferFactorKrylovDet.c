// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.JacquetRallisTransferFactorKrylovDet
// Imports: public import Init public meta import Init public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.FourierMatch
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_CommRing_toNonUnitalCommRing___redArg(lean_object*);
lean_object* lp_mathlib_NonUnitalNonAssocRing_toNonUnitalNonAssocSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* l_List_finRange(lean_object*);
lean_object* l_instDecidableEqFin___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Semiring_toNonUnitalSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Matrix_nonUnitalNonAssocSemiring___redArg(lean_object*, lean_object*);
lean_object* lp_mathlib_Semiring_toNonAssocSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Matrix_nonAssocSemiring___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Pi_single___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_tree_GlobalTheory_JR_full(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_npowBinRec_go___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lp_mathlib_Matrix_vecMul___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg___lam__0(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg___lam__0___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg___lam__0(lean_object* v_toZero_1_, lean_object* v_i_2_){
_start:
{
lean_inc(v_toZero_1_);
return v_toZero_1_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg___lam__0___boxed(lean_object* v_toZero_3_, lean_object* v_i_4_){
_start:
{
lean_object* v_res_5_; 
v_res_5_ = lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg___lam__0(v_toZero_3_, v_i_4_);
lean_dec(v_i_4_);
lean_dec(v_toZero_3_);
return v_res_5_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg(lean_object* v_inst_6_, lean_object* v_r_7_, lean_object* v_Y_8_, lean_object* v_i_9_, lean_object* v_a_10_){
_start:
{
lean_object* v___x_11_; lean_object* v___x_12_; lean_object* v_toSemiring_13_; lean_object* v___x_14_; lean_object* v_toZero_15_; lean_object* v___x_16_; lean_object* v_toAddMonoidWithOne_17_; lean_object* v_toOne_18_; lean_object* v___x_19_; lean_object* v___x_20_; lean_object* v___x_21_; lean_object* v___x_22_; lean_object* v___x_23_; lean_object* v___x_24_; lean_object* v___x_25_; lean_object* v___x_26_; lean_object* v_toMul_27_; lean_object* v_toOne_28_; lean_object* v___f_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; lean_object* v___x_33_; 
v___x_11_ = lp_mathlib_CommRing_toNonUnitalCommRing___redArg(v_inst_6_);
v___x_12_ = lp_mathlib_NonUnitalNonAssocRing_toNonUnitalNonAssocSemiring___redArg(v___x_11_);
v_toSemiring_13_ = lean_ctor_get(v_inst_6_, 0);
lean_inc_ref_n(v_toSemiring_13_, 2);
v___x_14_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_13_);
v_toZero_15_ = lean_ctor_get(v___x_14_, 1);
lean_inc(v_toZero_15_);
lean_dec_ref(v___x_14_);
v___x_16_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_inst_6_);
v_toAddMonoidWithOne_17_ = lean_ctor_get(v___x_16_, 1);
lean_inc_ref(v_toAddMonoidWithOne_17_);
lean_dec_ref(v___x_16_);
v_toOne_18_ = lean_ctor_get(v_toAddMonoidWithOne_17_, 2);
lean_inc(v_toOne_18_);
lean_dec_ref(v_toAddMonoidWithOne_17_);
v___x_19_ = lean_unsigned_to_nat(1u);
v___x_20_ = lean_nat_add(v_r_7_, v___x_19_);
lean_inc(v___x_20_);
v___x_21_ = l_List_finRange(v___x_20_);
v___x_22_ = lean_alloc_closure((void*)(l_instDecidableEqFin___boxed), 3, 1);
lean_closure_set(v___x_22_, 0, v___x_20_);
v___x_23_ = lp_mathlib_Semiring_toNonUnitalSemiring___redArg(v_toSemiring_13_);
lean_inc_n(v___x_21_, 2);
v___x_24_ = lp_mathlib_Matrix_nonUnitalNonAssocSemiring___redArg(v___x_23_, v___x_21_);
v___x_25_ = lp_mathlib_Semiring_toNonAssocSemiring___redArg(v_toSemiring_13_);
lean_inc_ref(v___x_22_);
v___x_26_ = lp_mathlib_Matrix_nonAssocSemiring___redArg(v___x_25_, v___x_21_, v___x_22_);
v_toMul_27_ = lean_ctor_get(v___x_24_, 1);
lean_inc(v_toMul_27_);
lean_dec_ref(v___x_24_);
v_toOne_28_ = lean_ctor_get(v___x_26_, 1);
lean_inc(v_toOne_28_);
lean_dec_ref(v___x_26_);
v___f_29_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg___lam__0___boxed), 2, 1);
lean_closure_set(v___f_29_, 0, v_toZero_15_);
lean_inc(v_r_7_);
v___x_30_ = lean_alloc_closure((void*)(lp_mathlib_Pi_single___boxed), 7, 6);
lean_closure_set(v___x_30_, 0, lean_box(0));
lean_closure_set(v___x_30_, 1, lean_box(0));
lean_closure_set(v___x_30_, 2, v___f_29_);
lean_closure_set(v___x_30_, 3, v___x_22_);
lean_closure_set(v___x_30_, 4, v_r_7_);
lean_closure_set(v___x_30_, 5, v_toOne_18_);
v___x_31_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_JR_full), 5, 3);
lean_closure_set(v___x_31_, 0, v_r_7_);
lean_closure_set(v___x_31_, 1, lean_box(0));
lean_closure_set(v___x_31_, 2, v_Y_8_);
v___x_32_ = lp_mathlib_npowBinRec_go___redArg(v_toMul_27_, v_i_9_, v_toOne_28_, v___x_31_);
v___x_33_ = lp_mathlib_Matrix_vecMul___redArg(v___x_12_, v___x_21_, v___x_30_, v___x_32_, v_a_10_);
return v___x_33_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg___boxed(lean_object* v_inst_34_, lean_object* v_r_35_, lean_object* v_Y_36_, lean_object* v_i_37_, lean_object* v_a_38_){
_start:
{
lean_object* v_res_39_; 
v_res_39_ = lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg(v_inst_34_, v_r_35_, v_Y_36_, v_i_37_, v_a_38_);
lean_dec(v_i_37_);
return v_res_39_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow(lean_object* v_k_40_, lean_object* v_inst_41_, lean_object* v_r_42_, lean_object* v_Y_43_, lean_object* v_i_44_, lean_object* v_a_45_){
_start:
{
lean_object* v___x_46_; 
v___x_46_ = lp_tree_GlobalTheory_JR_TransferFactor_vrow___redArg(v_inst_41_, v_r_42_, v_Y_43_, v_i_44_, v_a_45_);
return v___x_46_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_TransferFactor_vrow___boxed(lean_object* v_k_47_, lean_object* v_inst_48_, lean_object* v_r_49_, lean_object* v_Y_50_, lean_object* v_i_51_, lean_object* v_a_52_){
_start:
{
lean_object* v_res_53_; 
v_res_53_ = lp_tree_GlobalTheory_JR_TransferFactor_vrow(v_k_47_, v_inst_48_, v_r_49_, v_Y_50_, v_i_51_, v_a_52_);
lean_dec(v_i_51_);
return v_res_53_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_FourierMatch(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_JacquetRallisTransferFactorKrylovDet(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_FourierMatch(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
