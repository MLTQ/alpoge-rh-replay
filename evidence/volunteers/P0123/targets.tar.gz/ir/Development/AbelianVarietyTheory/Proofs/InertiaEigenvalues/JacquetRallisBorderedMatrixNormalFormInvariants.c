// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.JacquetRallisBorderedMatrixNormalFormInvariants
// Imports: public import Init public meta import Init public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.FourierMatch
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lp_mathlib_Field_toSemifield___redArg(lean_object*);
lean_object* lp_mathlib_Semifield_toDivisionSemiring___redArg(lean_object*);
lean_object* lp_mathlib_instMulZeroClassOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_Field_toDivisionRing___redArg(lean_object*);
lean_object* lp_mathlib_Ring_toAddGroupWithOne___redArg(lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_NormalFormL_ev___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_NormalFormL_ev___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_NormalFormL_ev(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_NormalFormL_ev___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_NormalFormL_ev___redArg(lean_object* v_inst_1_, lean_object* v_i_2_, lean_object* v_j_3_){
_start:
{
uint8_t v___x_4_; 
v___x_4_ = lean_nat_dec_eq(v_j_3_, v_i_2_);
if (v___x_4_ == 0)
{
lean_object* v___x_5_; lean_object* v___x_6_; lean_object* v_toSemiring_7_; lean_object* v___x_8_; lean_object* v_toZero_9_; 
v___x_5_ = lp_mathlib_Field_toSemifield___redArg(v_inst_1_);
lean_dec_ref(v_inst_1_);
v___x_6_ = lp_mathlib_Semifield_toDivisionSemiring___redArg(v___x_5_);
v_toSemiring_7_ = lean_ctor_get(v___x_6_, 0);
lean_inc_ref(v_toSemiring_7_);
lean_dec_ref(v___x_6_);
v___x_8_ = lp_mathlib_instMulZeroClassOfSemiring___redArg(v_toSemiring_7_);
v_toZero_9_ = lean_ctor_get(v___x_8_, 1);
lean_inc(v_toZero_9_);
lean_dec_ref(v___x_8_);
return v_toZero_9_;
}
else
{
lean_object* v___x_10_; lean_object* v_toRing_11_; lean_object* v___x_12_; lean_object* v_toAddMonoidWithOne_13_; lean_object* v_toOne_14_; 
v___x_10_ = lp_mathlib_Field_toDivisionRing___redArg(v_inst_1_);
v_toRing_11_ = lean_ctor_get(v___x_10_, 0);
lean_inc_ref(v_toRing_11_);
lean_dec_ref(v___x_10_);
v___x_12_ = lp_mathlib_Ring_toAddGroupWithOne___redArg(v_toRing_11_);
v_toAddMonoidWithOne_13_ = lean_ctor_get(v___x_12_, 1);
lean_inc_ref(v_toAddMonoidWithOne_13_);
lean_dec_ref(v___x_12_);
v_toOne_14_ = lean_ctor_get(v_toAddMonoidWithOne_13_, 2);
lean_inc(v_toOne_14_);
lean_dec_ref(v_toAddMonoidWithOne_13_);
return v_toOne_14_;
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_NormalFormL_ev___redArg___boxed(lean_object* v_inst_15_, lean_object* v_i_16_, lean_object* v_j_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = lp_tree_GlobalTheory_JR_NormalFormL_ev___redArg(v_inst_15_, v_i_16_, v_j_17_);
lean_dec(v_j_17_);
lean_dec(v_i_16_);
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_NormalFormL_ev(lean_object* v_r_19_, lean_object* v_k_20_, lean_object* v_inst_21_, lean_object* v_i_22_, lean_object* v_j_23_){
_start:
{
lean_object* v___x_24_; 
v___x_24_ = lp_tree_GlobalTheory_JR_NormalFormL_ev___redArg(v_inst_21_, v_i_22_, v_j_23_);
return v___x_24_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_JR_NormalFormL_ev___boxed(lean_object* v_r_25_, lean_object* v_k_26_, lean_object* v_inst_27_, lean_object* v_i_28_, lean_object* v_j_29_){
_start:
{
lean_object* v_res_30_; 
v_res_30_ = lp_tree_GlobalTheory_JR_NormalFormL_ev(v_r_25_, v_k_26_, v_inst_27_, v_i_28_, v_j_29_);
lean_dec(v_j_29_);
lean_dec(v_i_28_);
lean_dec(v_r_25_);
return v_res_30_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_FourierMatch(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_JacquetRallisBorderedMatrixNormalFormInvariants(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_FourierMatch(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
