// Lean compiler output
// Module: Development.AbelianVarietyTheory.Proofs.InertiaEigenvalues.OverExtAlgebraMap
// Imports: public import Init public meta import Init public import Mathlib public import Development.AbelianVarietyTheory.Definitions.NonGaloisDescent.UnitLemmaGroup
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lp_mathlib_instDistribOfSemiring___redArg(lean_object*);
lean_object* lp_mathlib_RingHom_comp___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Unr_overExt___redArg___lam__0(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Unr_overExt___redArg___lam__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Unr_overExt___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Unr_overExt(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Unr_overExt___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Unr_overExt___redArg___lam__0(lean_object* v_00_u03c8_1_, lean_object* v_toMul_2_, lean_object* v_c_3_, lean_object* v_x_4_){
_start:
{
lean_object* v___x_5_; lean_object* v___x_6_; 
v___x_5_ = lean_apply_1(v_00_u03c8_1_, v_c_3_);
v___x_6_ = lean_apply_2(v_toMul_2_, v___x_5_, v_x_4_);
return v___x_6_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Unr_overExt___redArg___lam__1(lean_object* v_algebraMap_7_, lean_object* v_00_u03c8_8_, lean_object* v_toMul_9_, lean_object* v_c_10_, lean_object* v_x_11_){
_start:
{
lean_object* v___x_12_; lean_object* v___x_13_; 
v___x_12_ = lp_mathlib_RingHom_comp___redArg___lam__0(v_algebraMap_7_, v_00_u03c8_8_, v_c_10_);
v___x_13_ = lean_apply_2(v_toMul_9_, v___x_12_, v_x_11_);
return v___x_13_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Unr_overExt___redArg(lean_object* v_K_x27_14_, lean_object* v_B_15_, lean_object* v_00_u03c8_16_){
_start:
{
lean_object* v_cA_17_; lean_object* v_00_u03c3_18_; lean_object* v_g_19_; lean_object* v___x_21_; uint8_t v_isShared_22_; uint8_t v_isSharedCheck_50_; 
v_cA_17_ = lean_ctor_get(v_B_15_, 0);
v_00_u03c3_18_ = lean_ctor_get(v_B_15_, 3);
v_g_19_ = lean_ctor_get(v_B_15_, 4);
v_isSharedCheck_50_ = !lean_is_exclusive(v_B_15_);
if (v_isSharedCheck_50_ == 0)
{
lean_object* v_unused_51_; lean_object* v_unused_52_; 
v_unused_51_ = lean_ctor_get(v_B_15_, 2);
lean_dec(v_unused_51_);
v_unused_52_ = lean_ctor_get(v_B_15_, 1);
lean_dec(v_unused_52_);
v___x_21_ = v_B_15_;
v_isShared_22_ = v_isSharedCheck_50_;
goto v_resetjp_20_;
}
else
{
lean_inc(v_g_19_);
lean_inc(v_00_u03c3_18_);
lean_inc(v_cA_17_);
lean_dec(v_B_15_);
v___x_21_ = lean_box(0);
v_isShared_22_ = v_isSharedCheck_50_;
goto v_resetjp_20_;
}
v_resetjp_20_:
{
lean_object* v_toSemiring_23_; lean_object* v___x_24_; lean_object* v_toMul_25_; lean_object* v___x_27_; uint8_t v_isShared_28_; uint8_t v_isSharedCheck_48_; 
v_toSemiring_23_ = lean_ctor_get(v_cA_17_, 0);
lean_inc_ref(v_toSemiring_23_);
v___x_24_ = lp_mathlib_instDistribOfSemiring___redArg(v_toSemiring_23_);
v_toMul_25_ = lean_ctor_get(v___x_24_, 0);
v_isSharedCheck_48_ = !lean_is_exclusive(v___x_24_);
if (v_isSharedCheck_48_ == 0)
{
lean_object* v_unused_49_; 
v_unused_49_ = lean_ctor_get(v___x_24_, 1);
lean_dec(v_unused_49_);
v___x_27_ = v___x_24_;
v_isShared_28_ = v_isSharedCheck_48_;
goto v_resetjp_26_;
}
else
{
lean_inc(v_toMul_25_);
lean_dec(v___x_24_);
v___x_27_ = lean_box(0);
v_isShared_28_ = v_isSharedCheck_48_;
goto v_resetjp_26_;
}
v_resetjp_26_:
{
lean_object* v___f_29_; lean_object* v___x_31_; 
lean_inc(v_toMul_25_);
lean_inc_n(v_00_u03c8_16_, 2);
v___f_29_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_UnitLemma_Unr_overExt___redArg___lam__0), 4, 2);
lean_closure_set(v___f_29_, 0, v_00_u03c8_16_);
lean_closure_set(v___f_29_, 1, v_toMul_25_);
if (v_isShared_28_ == 0)
{
lean_ctor_set(v___x_27_, 1, v_00_u03c8_16_);
lean_ctor_set(v___x_27_, 0, v___f_29_);
v___x_31_ = v___x_27_;
goto v_reusejp_30_;
}
else
{
lean_object* v_reuseFailAlloc_47_; 
v_reuseFailAlloc_47_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_47_, 0, v___f_29_);
lean_ctor_set(v_reuseFailAlloc_47_, 1, v_00_u03c8_16_);
v___x_31_ = v_reuseFailAlloc_47_;
goto v_reusejp_30_;
}
v_reusejp_30_:
{
lean_object* v_aOE_32_; lean_object* v_algebraMap_33_; lean_object* v___x_35_; uint8_t v_isShared_36_; uint8_t v_isSharedCheck_45_; 
v_aOE_32_ = lean_ctor_get(v_K_x27_14_, 2);
lean_inc_ref(v_aOE_32_);
lean_dec_ref(v_K_x27_14_);
v_algebraMap_33_ = lean_ctor_get(v_aOE_32_, 1);
v_isSharedCheck_45_ = !lean_is_exclusive(v_aOE_32_);
if (v_isSharedCheck_45_ == 0)
{
lean_object* v_unused_46_; 
v_unused_46_ = lean_ctor_get(v_aOE_32_, 0);
lean_dec(v_unused_46_);
v___x_35_ = v_aOE_32_;
v_isShared_36_ = v_isSharedCheck_45_;
goto v_resetjp_34_;
}
else
{
lean_inc(v_algebraMap_33_);
lean_dec(v_aOE_32_);
v___x_35_ = lean_box(0);
v_isShared_36_ = v_isSharedCheck_45_;
goto v_resetjp_34_;
}
v_resetjp_34_:
{
lean_object* v___f_37_; lean_object* v___f_38_; lean_object* v___x_40_; 
lean_inc(v_00_u03c8_16_);
lean_inc(v_algebraMap_33_);
v___f_37_ = lean_alloc_closure((void*)(lp_tree_GlobalTheory_UnitLemma_Unr_overExt___redArg___lam__1), 5, 3);
lean_closure_set(v___f_37_, 0, v_algebraMap_33_);
lean_closure_set(v___f_37_, 1, v_00_u03c8_16_);
lean_closure_set(v___f_37_, 2, v_toMul_25_);
v___f_38_ = lean_alloc_closure((void*)(lp_mathlib_RingHom_comp___redArg___lam__0), 3, 2);
lean_closure_set(v___f_38_, 0, v_algebraMap_33_);
lean_closure_set(v___f_38_, 1, v_00_u03c8_16_);
if (v_isShared_36_ == 0)
{
lean_ctor_set(v___x_35_, 1, v___f_38_);
lean_ctor_set(v___x_35_, 0, v___f_37_);
v___x_40_ = v___x_35_;
goto v_reusejp_39_;
}
else
{
lean_object* v_reuseFailAlloc_44_; 
v_reuseFailAlloc_44_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v_reuseFailAlloc_44_, 0, v___f_37_);
lean_ctor_set(v_reuseFailAlloc_44_, 1, v___f_38_);
v___x_40_ = v_reuseFailAlloc_44_;
goto v_reusejp_39_;
}
v_reusejp_39_:
{
lean_object* v___x_42_; 
if (v_isShared_22_ == 0)
{
lean_ctor_set(v___x_21_, 2, v___x_40_);
lean_ctor_set(v___x_21_, 1, v___x_31_);
v___x_42_ = v___x_21_;
goto v_reusejp_41_;
}
else
{
lean_object* v_reuseFailAlloc_43_; 
v_reuseFailAlloc_43_ = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(v_reuseFailAlloc_43_, 0, v_cA_17_);
lean_ctor_set(v_reuseFailAlloc_43_, 1, v___x_31_);
lean_ctor_set(v_reuseFailAlloc_43_, 2, v___x_40_);
lean_ctor_set(v_reuseFailAlloc_43_, 3, v_00_u03c3_18_);
lean_ctor_set(v_reuseFailAlloc_43_, 4, v_g_19_);
v___x_42_ = v_reuseFailAlloc_43_;
goto v_reusejp_41_;
}
v_reusejp_41_:
{
return v___x_42_;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Unr_overExt(lean_object* v_K_53_, lean_object* v_K_x27_54_, lean_object* v_00_u03c6_55_, lean_object* v_B_56_, lean_object* v_00_u03c8_57_, lean_object* v_h_u03c8_58_, lean_object* v_h_u03c3_59_){
_start:
{
lean_object* v___x_60_; 
v___x_60_ = lp_tree_GlobalTheory_UnitLemma_Unr_overExt___redArg(v_K_x27_54_, v_B_56_, v_00_u03c8_57_);
return v___x_60_;
}
}
LEAN_EXPORT lean_object* lp_tree_GlobalTheory_UnitLemma_Unr_overExt___boxed(lean_object* v_K_61_, lean_object* v_K_x27_62_, lean_object* v_00_u03c6_63_, lean_object* v_B_64_, lean_object* v_00_u03c8_65_, lean_object* v_h_u03c8_66_, lean_object* v_h_u03c3_67_){
_start:
{
lean_object* v_res_68_; 
v_res_68_ = lp_tree_GlobalTheory_UnitLemma_Unr_overExt(v_K_61_, v_K_x27_62_, v_00_u03c6_63_, v_B_64_, v_00_u03c8_65_, v_h_u03c8_66_, v_h_u03c3_67_);
lean_dec(v_00_u03c6_63_);
lean_dec_ref(v_K_61_);
return v_res_68_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_mathlib_Mathlib(uint8_t builtin);
lean_object* initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_UnitLemmaGroup(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_tree_Development_AbelianVarietyTheory_Proofs_InertiaEigenvalues_OverExtAlgebraMap(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_mathlib_Mathlib(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_tree_Development_AbelianVarietyTheory_Definitions_NonGaloisDescent_UnitLemmaGroup(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
